# Noor Beauty Lounge ایپ: چلانے کا طریقہ

یہ ایک Flutter ایپ ہے جو Android اور iPhone دونوں پر چلتی ہے۔ ڈیٹا Firebase میں محفوظ ہوتا ہے، اس لیے کلائنٹ اور مالک دونوں کو ایک ہی بُکنگز نظر آتی ہیں۔ نیچے کے مراحل ترتیب سے کریں۔ کہیں بھی کوئی ایرر آئے تو اس کا اسکرین شاٹ Claude کو بھیج دیں۔

---

## مرحلہ 1: کمپیوٹر تیار کریں (صرف ایک بار)

1. **Flutter** انسٹال کریں: https://docs.flutter.dev/get-started/install پر جائیں اور اپنا سسٹم (Windows یا Mac) چنیں۔
2. **Android Studio** انسٹال کریں: https://developer.android.com/studio
3. **Node.js** انسٹال کریں: https://nodejs.org (LTS والا ورژن)۔ یہ Firebase کے ٹول کے لیے ضروری ہے۔
4. Terminal کھولیں (Windows پر "PowerShell") اور یہ کمانڈ چلائیں:

```
flutter doctor
```

جن چیزوں کے آگے ✗ ہو، ان کے بارے میں وہیں ہدایات لکھی ہوتی ہیں۔ Android والی لائنیں ✓ ہو جائیں تو آگے بڑھیں۔

---

## مرحلہ 2: پروجیکٹ کھولیں

1. `noor_salon.zip` کو ان زِپ کریں، مثلاً `Documents/noor_salon` میں۔
2. Terminal میں اس فولڈر میں جائیں:

```
cd Documents/noor_salon
```

3. Android اور iPhone کے فولڈر بنائیں۔ یہ کمانڈ آپ کی lib والی فائلیں نہیں بدلتی:

```
flutter create . --org com.noorbeauty --platforms android,ios
```

---

## مرحلہ 3: Firebase بنائیں

1. https://console.firebase.google.com پر جائیں، اپنے Google اکاؤنٹ سے لاگ اِن کریں اور **Create a project** دبائیں۔ نام مثلاً `noor-salon` رکھیں۔
2. بائیں مینو سے **Authentication** کھولیں، **Get started** دبائیں، پھر **Sign-in method** میں **Phone** کو Enable کریں۔
3. بائیں مینو سے **Firestore Database** کھولیں اور **Create database** دبائیں۔ لوکیشن کوئی قریبی رکھیں (مثلاً `asia-south1`)۔ **Production mode** چنیں۔
4. Firestore میں **Rules** ٹیب کھولیں۔ وہاں جو لکھا ہو سب مٹا دیں، پھر پروجیکٹ کی فائل `firestore.rules` کھول کر اس کا پورا متن پیسٹ کریں اور **Publish** دبائیں۔ اسی سے کلائنٹ صرف اپنی بُکنگز دیکھ سکتا ہے اور خود کو "Paid" نہیں کر سکتا۔

---

## مرحلہ 4: ایپ کو Firebase سے جوڑیں

Terminal میں یہ کمانڈز ایک ایک کر کے چلائیں:

```
npm install -g firebase-tools
firebase login
dart pub global activate flutterfire_cli
flutterfire configure
```

`flutterfire configure` پوچھے گا کہ کون سا پروجیکٹ چاہیے: `noor-salon` چنیں۔ Platforms میں **android** اور **ios** دونوں رکھیں۔ یہ خود `lib/firebase_options.dart` فائل بنا دے گا۔

> اگر `flutterfire` کمانڈ نہ ملے تو Terminal بند کر کے دوبارہ کھولیں۔ پھر بھی نہ ملے تو یہ ایرر Claude کو بھیجیں۔

---

## مرحلہ 5: Android کی دو سیٹنگز

**(الف) minSdk:** فائل `android/app/build.gradle.kts` کھولیں (یا `build.gradle` اگر `.kts` نہ ہو)۔ `minSdk` والی لائن ڈھونڈیں اور اسے یوں کر دیں:

```
minSdk = 23
```

**(ب) SHA کیز (فون OTP کے لیے ضروری):** Terminal میں:

```
cd android
./gradlew signingReport
cd ..
```

(Windows پر `./gradlew` کی جگہ `gradlew` لکھیں)

آؤٹ پٹ میں `Variant: debug` کے نیچے **SHA1** اور **SHA-256** لکھے ہوں گے۔ Firebase Console میں ⚙️ **Project settings** کھولیں، اپنی Android ایپ تک نیچے جائیں، **Add fingerprint** دبائیں اور دونوں کیز ایک ایک کر کے ڈال دیں۔

---

## مرحلہ 6: ٹیسٹ نمبر بنائیں (مفت)

اصلی SMS بھیجنے کے لیے Firebase کا پیڈ پلان (Blaze) ضروری ہے۔ ٹیسٹنگ کے لیے مفت ٹیسٹ نمبر استعمال کریں:

Firebase Console میں **Authentication > Sign-in method > Phone** کھولیں، پھر **Phone numbers for testing** میں یہ دو نمبر ڈالیں:

| نمبر | کوڈ | کس کے لیے |
|---|---|---|
| +92 300 0000001 | 123456 | مالک (آپ) |
| +92 300 0000002 | 123456 | کلائنٹ |

---

## مرحلہ 7: ایپ چلائیں

1. فون پر **Developer options** اور **USB debugging** آن کریں۔ Google پر "USB debugging on" اور فون کا ماڈل لکھ کر طریقہ مل جائے گا۔
2. فون USB سے کمپیوٹر کے ساتھ لگائیں (یا Android Studio میں ایمولیٹر چلائیں)۔
3. Terminal میں:

```
flutter pub get
flutter run
```

پہلی بار بلڈ ہونے میں 5 سے 10 منٹ لگ سکتے ہیں۔

---

## مرحلہ 8: پہلی بار استعمال

1. ایپ کھلے تو **مالک والا نمبر** `300 0000001` ڈالیں اور کوڈ `123456` لکھیں۔
2. اپنا نام لکھیں۔
3. **Set up my salon** دبائیں۔ اب آپ مالک بن گئے ہیں، اور سروسز، 4 آرٹسٹس اور 2 آفرز خود بن جائیں گی۔
4. **Settings** میں جا کر سیلون کا اصل نام، شہر، کرنسی، اوقات، قیمتیں اور اسٹاف بدلیں۔
5. **Open client app view** دبا کر دیکھیں کہ کلائنٹ کو ایپ کیسی نظر آتی ہے۔
6. دوسرے فون یا ایمولیٹر پر کلائنٹ والے نمبر `300 0000002` سے لاگ اِن کریں اور بُکنگ کریں۔ وہ بُکنگ آپ کے Today والے صفحے پر فوراً آ جائے گی۔

> **اہم:** جو بندہ سب سے پہلے "Set up my salon" دبائے وہی مالک بنتا ہے۔ اس لیے سب سے پہلے خود اپنے نمبر سے لاگ اِن کریں۔

---

## iPhone کے لیے

iPhone کی ایپ بنانے کے لیے **Mac کمپیوٹر**، **Xcode** اور **Apple Developer اکاؤنٹ** ضروری ہیں۔ iPhone پر فون OTP کے لیے Firebase میں APNs کی سیٹنگ بھی کرنی پڑتی ہے۔ پہلے Android پر سب ٹھیک چلا لیں، پھر iPhone کا مرحلہ Claude سے پوچھیں۔

---

## Play Store پر لگانا (بعد میں)

```
flutter build appbundle
```

یہ `build/app/outputs/bundle/release/app-release.aab` فائل بناتا ہے۔ اسے Google Play Console پر اپلوڈ کیا جاتا ہے۔ اس سے پہلے ایپ کا اپنا signing key، آئیکن اور Privacy Policy بنانا ہوگا۔ اس کے لیے بھی Claude سے مدد لیں۔

---

## مسئلے اور حل

| مسئلہ | حل |
|---|---|
| `firebase_options.dart not found` | مرحلہ 4 والا `flutterfire configure` دوبارہ چلائیں |
| OTP نہیں آتا یا `missing-client-identifier` | مرحلہ 5 (ب) کی SHA کیز چیک کریں، پھر `flutterfire configure` دوبارہ چلائیں |
| `BILLING_NOT_ENABLED` | اصلی نمبر استعمال ہو رہا ہے۔ ٹیسٹ نمبر استعمال کریں یا Blaze پلان لیں |
| `permission-denied` | مرحلہ 3 والے Rules دوبارہ پیسٹ کر کے Publish کریں |
| پیکیج کے ورژن کا ایرر | `flutter pub upgrade --major-versions` چلائیں |
| کوئی اور ایرر | ایرر کا اسکرین شاٹ Claude کو بھیجیں |

---

## فولڈر میں کیا ہے

- `lib/main.dart`: ایپ یہیں سے شروع ہوتی ہے
- `lib/theme.dart`: رنگ اور فونٹ (Cinzel + Lato)
- `lib/screens/auth.dart`: لاگ اِن، نام اور سیلون سیٹ اَپ
- `lib/screens/customer.dart`: کلائنٹ کی ایپ (Home, Bookings, Offers, Profile)
- `lib/screens/booking_flow.dart`: بُکنگ کے چار مرحلے اور کنفرمیشن ٹکٹ
- `lib/screens/owner.dart`: مالک کا ڈیش بورڈ (Today, Clients, Payments, Settings)
- `lib/repo.dart`: Firebase سے ڈیٹا پڑھنا اور لکھنا، اور ڈبل بُکنگ کی روک تھام
- `firestore.rules`: ڈیٹا کی حفاظت کے اصول

---

## ایڈمن اور سیلون مالک (نام بدلنے کی حد)

- جو شخص سب سے پہلے **Set up my salon** دبائے وہ **ایڈمن** بنتا ہے، یعنی آپ۔ ایڈمن ہر چیز جتنی بار چاہے بدل سکتا ہے، سیلون کا نام بھی۔
- سیلون مالک کو اس کے اپنے فون پر چلانے کے لیے: **Settings** میں سب سے اوپر **Admin** والے کارڈ پر **+ Owner** دبائیں اور مالک کا موبائل نمبر ڈالیں۔
- وہ مالک جب اپنے فون پر اسی نمبر سے لاگ اِن کرے گا تو اسے مالک والا ڈیش بورڈ ملے گا۔ وہ قیمتیں، اسٹاف، اوقات اور باقی سب کچھ بدل سکے گا، لیکن **سیلون کا نام صرف 2 بار**۔ اس کے بعد نام لاک ہو جائے گا۔
- اگر مالک کو دوبارہ نام بدلنے کی اجازت دینی ہو تو Admin کارڈ میں **Reset** دبا دیں۔
- یہ حد Firebase کے سرور پر بھی لگی ہے، اس لیے ایپ میں کوئی چالاکی کر کے اسے نہیں توڑا جا سکتا۔ شرط یہ ہے کہ نئی `firestore.rules` Publish کی گئی ہوں۔
