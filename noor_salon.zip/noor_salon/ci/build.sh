#!/usr/bin/env bash
# Builds the Android APK. Called by .github/workflows/build-apk.yml
# FULL app when both Firebase secrets exist, otherwise the DEMO app (no Firebase needed).
set -euo pipefail
ROOT="$(pwd)"
RUN="${RUN:-0}"

if [ -n "${GOOGLE_SERVICES_JSON:-}" ] && [ -n "${KEYSTORE_BASE64:-}" ]; then
  MODE=full; DIR="$ROOT"; NAME=noor_salon
else
  MODE=demo; DIR="$ROOT/demo_app"; NAME=noor_salon_demo
fi
echo "==> Building the $MODE app"
cd "$DIR"

flutter create . --org com.noorbeauty --project-name "$NAME" --platforms android

f=android/app/build.gradle.kts
[ -f "$f" ] || f=android/app/build.gradle
sed -i -E 's/minSdk *= *flutter\.minSdkVersion/minSdk = 23/; s/minSdkVersion +flutter\.minSdkVersion/minSdkVersion 23/' "$f"
grep -nE "minSdk" "$f" || true

# Internet permission for release builds (fonts in demo, Firebase in full app)
m=android/app/src/main/AndroidManifest.xml
grep -q "android.permission.INTERNET" "$m" || sed -i 's#<application#<uses-permission android:name="android.permission.INTERNET"/>\n    <application#' "$m"

if [ -n "${KEYSTORE_BASE64:-}" ]; then
  mkdir -p ~/.android
  printf '%s' "$KEYSTORE_BASE64" | base64 -d > ~/.android/debug.keystore
  echo "Using the salon's fixed signing key"
fi

if [ "$MODE" = full ]; then
  printf '%s' "$GOOGLE_SERVICES_JSON" > google-services.json
  python3 tool/make_firebase_options.py google-services.json com.noorbeauty.noor_salon
  rm google-services.json
fi

flutter pub get
flutter build apk --release

OUT="$ROOT/NoorSalon-$MODE-$RUN.apk"
cp build/app/outputs/flutter-apk/app-release.apk "$OUT"
echo "APK ready: $OUT"
if [ -n "${GITHUB_ENV:-}" ]; then
  echo "APK_MODE=$MODE" >> "$GITHUB_ENV"
fi
