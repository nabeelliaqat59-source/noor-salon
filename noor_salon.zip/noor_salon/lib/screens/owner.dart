import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models.dart';
import '../repo.dart';
import '../state.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets.dart';
import 'booking_flow.dart';
import 'customer.dart';

class OwnerShell extends StatefulWidget {
  const OwnerShell({super.key});

  @override
  State<OwnerShell> createState() => _OwnerShellState();
}

class _OwnerShellState extends State<OwnerShell> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: IndexedStack(index: _tab, children: const [DashboardTab(), ClientsTab(), PaymentsTab(), SettingsTab()]),
      bottomNavigationBar: FloatNav(
        items: const [
          (Icons.grid_view_rounded, 'Today'),
          (Icons.people_outline, 'Clients'),
          (Icons.account_balance_wallet_outlined, 'Payments'),
          (Icons.tune, 'Settings'),
        ],
        index: _tab,
        onTap: (i) => setState(() => _tab = i),
      ),
    );
  }
}

Widget _chip(String label, bool on, VoidCallback onTap) => Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: on,
        onSelected: (_) => onTap(),
        showCheckmark: false,
        selectedColor: C.aub,
        backgroundColor: Colors.white,
        side: const BorderSide(color: C.line),
        shape: const StadiumBorder(),
        labelStyle: body(13, weight: FontWeight.w700, color: on ? C.gold : C.ink),
      ),
    );

Widget _kpi(String label, String value, {Color color = C.ink}) => Expanded(
      child: AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: body(12.5, color: C.mut)),
          const SizedBox(height: 2),
          FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(value, style: display(18, color: color))),
        ]),
      ),
    );

void _contactSheet(BuildContext context, String name, String phone) {
  showModalBottomSheet(
    context: context,
    builder: (ctx) => Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 28),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(name, style: display(22)),
        const SizedBox(height: 6),
        Text('Call or WhatsApp this client:', style: body(14, color: C.mut)),
        const SizedBox(height: 6),
        Text(phone.isEmpty ? 'No number saved' : phone, style: display(26)),
        const SizedBox(height: 18),
        Row(children: [
          Expanded(
            child: DarkButton('Copy number', color: C.soft, textColor: C.ink, onTap: () {
              Clipboard.setData(ClipboardData(text: phone));
              Navigator.of(ctx).pop();
              toast(context, 'Number copied');
            }),
          ),
          const SizedBox(width: 10),
          Expanded(child: DarkButton('Done', onTap: () => Navigator.of(ctx).pop())),
        ]),
      ]),
    ),
  );
}

// ----------------------------------------------------------------- TODAY
class DashboardTab extends StatefulWidget {
  const DashboardTab({super.key});

  @override
  State<DashboardTab> createState() => _DashboardTabState();
}

class _DashboardTabState extends State<DashboardTab> {
  String day = todayStr();
  late final Stream<List<Booking>> _stream = Repo.bookingsFrom(ymd(dayFromToday(-6)));

  Future<void> _act(Future<void> Function() f, String done) async {
    try {
      await f();
      if (mounted) toast(context, done);
    } catch (_) {
      if (mounted) toast(context, 'Could not update. Check your internet.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final s = app.settings;
        if (s == null) return const SizedBox.shrink();
        return StreamBuilder<List<Booking>>(
          stream: _stream,
          builder: (context, snap) {
            final all = snap.data ?? const <Booking>[];
            final week = [for (var i = -6; i <= 0; i++) ymd(dayFromToday(i))];
            final perDay = {for (final d in week) d: all.where((b) => b.paid && b.date == d).fold<int>(0, (a, b) => a + b.total)};
            final weekSum = perDay.values.fold<int>(0, (a, b) => a + b);
            final maxDay = perDay.values.fold<int>(1, (a, b) => b > a ? b : a);
            final list = all.where((b) => b.date == day && b.status != 'cancelled').toList()..sort((a, b) => a.time.compareTo(b.time));
            final expected = list.where((b) => b.status != 'noshow').fold<int>(0, (a, b) => a + b.total);
            final collected = list.where((b) => b.paid).fold<int>(0, (a, b) => a + b.total);
            final days = [for (var i = 0; i < 7; i++) ymd(dayFromToday(i))];
            final open = toMins(s.close) - toMins(s.open);

            return SafeArea(
              bottom: false,
              child: ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 120), children: [
                Row(children: [
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Eyebrow('${s.city} studio'),
                      Text(s.name, style: display(22)),
                    ]),
                  ),
                  CircleIconButton(Icons.add, onTap: () => openBookingFlow(context, walkIn: true, date: day)),
                ]),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(gradient: C.hero, borderRadius: BorderRadius.circular(28)),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Collected this week', style: body(13, color: C.onDarkMut)),
                    FoilText(app.money(weekSum), style: display(30)),
                    const SizedBox(height: 14),
                    SizedBox(
                      height: 96,
                      child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                        for (final d in week)
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 4),
                              child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                                AnimatedContainer(
                                  duration: const Duration(milliseconds: 500),
                                  curve: Curves.easeOutCubic,
                                  height: 4 + 66 * (perDay[d]! / maxDay),
                                  decoration: BoxDecoration(
                                    gradient: d == week.last ? C.foil : null,
                                    color: d == week.last ? null : Colors.white.withValues(alpha: .16),
                                    borderRadius: const BorderRadius.vertical(top: Radius.circular(8), bottom: Radius.circular(4)),
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(d == week.last ? 'Today' : dayName(pdate(d)).substring(0, 2),
                                    style: body(10.5, color: C.onDarkMut, weight: FontWeight.w700)),
                              ]),
                            ),
                          ),
                      ]),
                    ),
                  ]),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  height: 40,
                  child: ListView(scrollDirection: Axis.horizontal, children: [
                    for (final d in days)
                      _chip(d == days.first ? 'Today' : '${dayName(pdate(d))} ${pdate(d).day}', day == d, () => setState(() => day = d)),
                  ]),
                ),
                const SizedBox(height: 12),
                Row(children: [_kpi('Appointments', '${list.length}'), const SizedBox(width: 10), _kpi('Expected', app.money(expected))]),
                const SizedBox(height: 10),
                Row(children: [
                  _kpi('Collected', app.money(collected), color: C.ok),
                  const SizedBox(width: 10),
                  _kpi('Pending', app.money(expected - collected), color: C.warn),
                ]),
                SectionTitle('Schedule', trailing: MiniButton('Walk-in', icon: Icons.add, primary: true, onTap: () => openBookingFlow(context, walkIn: true, date: day))),
                if (!snap.hasData) const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator(color: C.gold2))),
                if (snap.hasData && list.isEmpty) const AppCard(child: EmptyNote('No appointments on this day.')),
                for (final b in list) _appt(context, b),
                const SectionTitle('Artist load'),
                AppCard(
                  child: Column(children: [
                    for (final t in app.staff)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        child: Builder(builder: (_) {
                          final m = list.where((b) => b.staff == t.id && b.status != 'noshow').fold<int>(0, (a, b) => a + b.dur);
                          return Column(children: [
                            Row(children: [
                              Container(width: 8, height: 8, decoration: BoxDecoration(color: avc(t.name), shape: BoxShape.circle)),
                              const SizedBox(width: 8),
                              Expanded(child: Text(t.name, style: body(13.5, weight: FontWeight.w700))),
                              Text('${(m / 60).toStringAsFixed(1)} h booked', style: body(13, color: C.mut)),
                            ]),
                            const SizedBox(height: 6),
                            GoldBar(open <= 0 ? 0 : m / open),
                          ]);
                        }),
                      ),
                  ]),
                ),
              ]),
            );
          },
        );
      },
    );
  }

  Widget _appt(BuildContext context, Booking b) {
    final parts = t12(b.time).split(' ');
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(
          width: 54,
          child: Padding(
            padding: const EdgeInsets.only(top: 14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text(parts[0], style: body(14, weight: FontWeight.w900)),
              Text(parts[1], style: body(12, color: C.mut, weight: FontWeight.w700)),
            ]),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Container(
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: const [BoxShadow(color: C.line, offset: Offset(0, 1))],
            ),
            child: IntrinsicHeight(
              child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Container(width: 4, color: avc(b.staffName)),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Expanded(child: Text(b.cust, style: body(15, weight: FontWeight.w700))),
                        StatusChip(b.status),
                      ]),
                      Text('${b.title} · ${b.dur} min', style: body(13, color: C.mut)),
                      const SizedBox(height: 2),
                      Text.rich(TextSpan(style: body(13, color: C.mut), children: [
                        TextSpan(text: '${b.staffName} · '),
                        TextSpan(text: app.money(b.total), style: body(13, weight: FontWeight.w900)),
                        TextSpan(text: ' · ${payOf(b.pay).label}'),
                        if (b.paid) TextSpan(text: '  ✓ Paid', style: body(13, color: C.ok, weight: FontWeight.w900)),
                      ])),
                      const SizedBox(height: 10),
                      Wrap(spacing: 6, runSpacing: 6, children: [
                        if (b.status == 'confirmed') ...[
                          MiniButton('Start', primary: true, onTap: () => _act(() => Repo.setStatus(b, 'in'), 'In chair')),
                          MiniButton('No-show', onTap: () => _act(() => Repo.setStatus(b, 'noshow'), 'Marked no-show')),
                          MiniButton('Move', onTap: () => openBookingFlow(context, resched: b)),
                        ],
                        if (b.status == 'in')
                          MiniButton('Complete', primary: true, onTap: () => _act(() => Repo.setStatus(b, 'done'), 'Completed')),
                        if (!b.paid && b.status != 'noshow')
                          MiniButton('Mark paid', onTap: () => _act(() => Repo.markPaid(b), '${app.money(b.total)} recorded')),
                        MiniButton('', icon: Icons.call_outlined, onTap: () => _contactSheet(context, b.cust, b.phone)),
                      ]),
                    ]),
                  ),
                ),
              ]),
            ),
          ),
        ),
      ]),
    );
  }
}

// ----------------------------------------------------------------- CLIENTS
class _Client {
  final String name, phone;
  int visits = 0;
  int spent = 0;
  String last = '';
  final List<Booking> history = [];
  _Client(this.name, this.phone);
}

List<_Client> _clients(List<Booking> all) {
  final m = <String, _Client>{};
  for (final b in all) {
    final key = b.phone.isEmpty ? b.cust : b.phone;
    final c = m.putIfAbsent(key, () => _Client(b.cust, b.phone));
    c.history.add(b);
    if (b.status == 'done') {
      c.visits++;
      c.spent += b.total;
      if (b.date.compareTo(c.last) > 0) c.last = b.date;
    }
  }
  final l = m.values.toList()..sort((a, b) => b.spent.compareTo(a.spent));
  return l;
}

class ClientsTab extends StatefulWidget {
  const ClientsTab({super.key});

  @override
  State<ClientsTab> createState() => _ClientsTabState();
}

class _ClientsTabState extends State<ClientsTab> {
  final _q = TextEditingController();
  late final Stream<List<Booking>> _stream = Repo.allBookings();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<Booking>>(
      stream: _stream,
      builder: (context, snap) {
        final all = _clients(snap.data ?? const []);
        final q = _q.text.trim().toLowerCase();
        final list = q.isEmpty ? all : all.where((c) => '${c.name} ${c.phone}'.toLowerCase().contains(q)).toList();
        return SafeArea(
          bottom: false,
          child: ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 120), children: [
            Row(children: [
              Expanded(child: Text('Clients', style: display(25))),
              Text('${all.length} total', style: body(13, color: C.mut)),
            ]),
            const SizedBox(height: 16),
            TextField(
              controller: _q,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search, color: C.mut), hintText: 'Search name or number'),
            ),
            const SizedBox(height: 14),
            AppCard(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
              child: list.isEmpty
                  ? EmptyNote(snap.hasData ? 'No clients yet.' : 'Loading…', icon: Icons.people_outline)
                  : Column(children: [
                      for (var i = 0; i < list.length; i++) ...[
                        if (i > 0) const Divider(height: 1, color: C.line),
                        InkWell(
                          onTap: () => _clientSheet(context, list[i]),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            child: Row(children: [
                              Avatar(list[i].name, ring: i < 3 && q.isEmpty),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Row(children: [
                                    Flexible(child: Text(list[i].name, style: body(15, weight: FontWeight.w700), overflow: TextOverflow.ellipsis)),
                                    if (i < 3 && q.isEmpty && list[i].spent > 0) ...[
                                      const SizedBox(width: 6),
                                      Text('★ VIP', style: body(11, color: C.gold2, weight: FontWeight.w900)),
                                    ],
                                  ]),
                                  Text('${list[i].visits} visits · last ${list[i].last.isEmpty ? '—' : fdate(list[i].last)}',
                                      style: body(13, color: C.mut)),
                                ]),
                              ),
                              Text(app.money(list[i].spent), style: display(14)),
                            ]),
                          ),
                        ),
                      ],
                    ]),
            ),
          ]),
        );
      },
    );
  }

  void _clientSheet(BuildContext context, _Client c) {
    final h = [...c.history]..sort((a, b) => b.sortKey.compareTo(a.sortKey));
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * .8),
        child: ListView(shrinkWrap: true, padding: const EdgeInsets.fromLTRB(20, 0, 20, 28), children: [
          Row(children: [
            Avatar(c.name, ring: true),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(c.name, style: display(20)),
                Text(c.phone, style: body(13, color: C.mut)),
              ]),
            ),
            CircleIconButton(Icons.call_outlined, onTap: () => _contactSheet(context, c.name, c.phone)),
          ]),
          const SizedBox(height: 14),
          Row(children: [_kpi('Visits', '${c.visits}'), const SizedBox(width: 10), _kpi('Lifetime', app.money(c.spent))]),
          const SizedBox(height: 16),
          Text('History', style: body(15, weight: FontWeight.w900)),
          for (final b in h)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(b.title, style: body(14, weight: FontWeight.w700)),
                    Text('${fdate(b.date)} · ${b.staffName} · ${app.money(b.total)}', style: body(12.5, color: C.mut)),
                  ]),
                ),
                StatusChip(b.status),
              ]),
            ),
          const SizedBox(height: 12),
          DarkButton('Close', onTap: () => Navigator.of(ctx).pop()),
        ]),
      ),
    );
  }
}

// ----------------------------------------------------------------- PAYMENTS
class PaymentsTab extends StatefulWidget {
  const PaymentsTab({super.key});

  @override
  State<PaymentsTab> createState() => _PaymentsTabState();
}

class _PaymentsTabState extends State<PaymentsTab> {
  late final Stream<List<Booking>> _stream = Repo.allBookings();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<Booking>>(
      stream: _stream,
      builder: (context, snap) {
        final all = snap.data ?? const <Booking>[];
        final from = ymd(dayFromToday(-6)), to = todayStr();
        final week = all.where((b) => b.paid && b.date.compareTo(from) >= 0 && b.date.compareTo(to) <= 0).toList();
        final sum = week.fold<int>(0, (a, b) => a + b.total);
        final dues = all.where((b) => !b.paid && (b.status == 'done' || b.status == 'in')).toList()
          ..sort((a, b) => b.sortKey.compareTo(a.sortKey));
        final recent = all.where((b) => b.paid).toList()..sort((a, b) => b.sortKey.compareTo(a.sortKey));
        return SafeArea(
          bottom: false,
          child: ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 120), children: [
            Text('Payments', style: display(25)),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(gradient: C.hero, borderRadius: BorderRadius.circular(28)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Collected · last 7 days', style: body(13, color: C.onDarkMut)),
                FoilText(app.money(sum), style: display(30)),
                Text('${week.length} paid visits · average ${app.money(week.isEmpty ? 0 : sum / week.length)}',
                    style: body(13, color: C.onDarkMut)),
              ]),
            ),
            const SizedBox(height: 12),
            AppCard(
              child: Column(children: [
                for (final e in payMethods.entries)
                  Builder(builder: (_) {
                    final v = week.where((b) => b.pay == e.key).fold<int>(0, (a, b) => a + b.total);
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      child: Column(children: [
                        Row(children: [
                          PayBadge(e.key, w: 34, h: 24),
                          const SizedBox(width: 10),
                          Expanded(child: Text(e.value.label, style: body(13.5, weight: FontWeight.w700))),
                          Text(app.money(v), style: body(13.5, weight: FontWeight.w900)),
                        ]),
                        const SizedBox(height: 6),
                        GoldBar(sum == 0 ? 0 : v / sum),
                      ]),
                    );
                  }),
              ]),
            ),
            SectionTitle('Dues',
                trailing: Text(app.money(dues.fold<int>(0, (a, b) => a + b.total)), style: body(14, color: C.warn, weight: FontWeight.w900))),
            AppCard(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
              child: dues.isEmpty
                  ? const EmptyNote('No pending dues.', icon: Icons.check_circle_outline)
                  : Column(children: [
                      for (final b in dues)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          child: Row(children: [
                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(b.cust, style: body(14.5, weight: FontWeight.w700)),
                                Text('${fdate(b.date)} · ${payOf(b.pay).label}', style: body(12.5, color: C.mut)),
                              ]),
                            ),
                            Text(app.money(b.total), style: body(13.5, weight: FontWeight.w900)),
                            const SizedBox(width: 8),
                            MiniButton('Paid', primary: true, onTap: () async {
                              try {
                                await Repo.markPaid(b);
                                if (context.mounted) toast(context, '${app.money(b.total)} recorded');
                              } catch (_) {
                                if (context.mounted) toast(context, 'Could not update. Try again.');
                              }
                            }),
                          ]),
                        ),
                    ]),
            ),
            const SectionTitle('Recent'),
            AppCard(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
              child: recent.isEmpty
                  ? const EmptyNote('Payments you mark as paid show here.', icon: Icons.receipt_long_outlined)
                  : Column(children: [
                      for (final b in recent.take(10))
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          child: Row(children: [
                            PayBadge(b.pay),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(b.cust, style: body(14, weight: FontWeight.w700)),
                                Text('${fdate(b.date)}, ${t12(b.time)}', style: body(12.5, color: C.mut)),
                              ]),
                            ),
                            Text('+${app.money(b.total)}', style: body(13.5, color: C.ok, weight: FontWeight.w900)),
                          ]),
                        ),
                    ]),
            ),
          ]),
        );
      },
    );
  }
}

// ----------------------------------------------------------------- SETTINGS
class SettingsTab extends StatefulWidget {
  const SettingsTab({super.key});

  @override
  State<SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<SettingsTab> {
  final name = TextEditingController();
  final tag = TextEditingController();
  final city = TextEditingController();
  final area = TextEditingController();
  final phone = TextEditingController();
  String cur = 'Rs', open = '11:00', close = '20:00';
  bool _busy = false;
  static const currencies = ['Rs', 'PKR', '\$', 'AED', 'SAR', '£', '€'];

  @override
  void initState() {
    super.initState();
    final s = app.settings;
    if (s != null) {
      name.text = s.name;
      tag.text = s.tag;
      city.text = s.city;
      area.text = s.area;
      phone.text = s.phone;
      cur = s.cur;
      open = s.open;
      close = s.close;
    }
  }

  Future<void> _pickTime(bool isOpen) async {
    final current = toMins(isOpen ? open : close);
    final t = await showTimePicker(context: context, initialTime: TimeOfDay(hour: current ~/ 60, minute: current % 60));
    if (t == null) return;
    final m = t.hour * 60 + (t.minute >= 30 ? 30 : 0);
    setState(() {
      if (isOpen) {
        open = fromMins(m);
      } else {
        close = fromMins(m);
      }
    });
  }

  /// Asks "are you sure?" and returns true if the owner taps Change.
  Future<bool> _confirmNameChange(int left) async {
    final ok = await showModalBottomSheet<bool>(
      context: context,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 28),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Change salon name?', style: display(22)),
          const SizedBox(height: 8),
          Text(
            left == 1
                ? 'This is your last name change. After this, the name is locked and only the app admin can change it.'
                : 'You can change the salon name $left more times. After that, it is locked.',
            style: body(15, color: C.mut, height: 1.4),
          ),
          const SizedBox(height: 20),
          Row(children: [
            Expanded(child: DarkButton('Go back', color: C.soft, textColor: C.ink, onTap: () => Navigator.of(ctx).pop(false))),
            const SizedBox(width: 10),
            Expanded(child: DarkButton('Change name', onTap: () => Navigator.of(ctx).pop(true))),
          ]),
        ]),
      ),
    );
    return ok == true;
  }

  Future<void> _save() async {
    final s = app.settings;
    if (s == null) return;
    final newName = name.text.trim();
    if (newName.isEmpty) {
      toast(context, 'Salon name is required');
      return;
    }
    if (toMins(close) <= toMins(open)) {
      toast(context, 'Closing time must be after opening time');
      return;
    }
    final nameChanged = newName != s.name;
    if (nameChanged && !app.isSuper) {
      if (s.nameChangesLeft <= 0) {
        name.text = s.name;
        toast(context, 'The salon name is locked. Ask the app admin to change it.');
        return;
      }
      if (!await _confirmNameChange(s.nameChangesLeft)) return;
    }
    if (!mounted) return;
    setState(() => _busy = true);
    try {
      await Repo.saveSettings({
        'name': newName,
        'tag': tag.text.trim(),
        'city': city.text.trim(),
        'area': area.text.trim(),
        'phone': phone.text.trim(),
        'cur': cur,
        'open': open,
        'close': close,
        if (nameChanged && !app.isSuper) 'nameChanges': s.nameChanges + 1,
      });
      if (mounted) toast(context, 'Salon details saved');
    } catch (_) {
      if (mounted) toast(context, 'Could not save. Try again.');
    }
    if (mounted) setState(() => _busy = false);
  }

  String? _normalPhone(String raw) {
    var d = raw.replaceAll(RegExp(r'\D'), '');
    if (d.startsWith('92')) d = d.substring(2);
    if (d.startsWith('0')) d = d.substring(1);
    return d.length == 10 ? '+92$d' : null;
  }

  void _addOwner(BuildContext context) {
    final ctrl = TextEditingController();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(20, 0, 20, 24 + MediaQuery.of(ctx).viewInsets.bottom),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Add salon owner', style: display(22)),
          const SizedBox(height: 8),
          Text(
            'When this number signs in, it opens the owner dashboard. They can edit everything, but change the salon name only ${SalonSettings.maxNameChanges} times.',
            style: body(14, color: C.mut, height: 1.4),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: ctrl,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(labelText: 'Owner mobile number', hintText: '0300 1234567'),
          ),
          const SizedBox(height: 16),
          DarkButton('Add owner', onTap: () async {
            final p = _normalPhone(ctrl.text);
            if (p == null) {
              toast(context, 'Enter a 10-digit mobile number, like 0300 1234567');
              return;
            }
            final list = [...?app.settings?.ownerPhones];
            if (!list.contains(p)) list.add(p);
            Navigator.of(ctx).pop();
            try {
              await Repo.setOwnerPhones(list);
              if (context.mounted) toast(context, '$p is now an owner');
            } catch (_) {
              if (context.mounted) toast(context, 'Could not save. Try again.');
            }
          }),
        ]),
      ),
    );
  }

  Widget _adminCard(BuildContext context) {
    final s = app.settings!;
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.verified_user_outlined, color: C.gold2),
          const SizedBox(width: 8),
          Expanded(child: Text('Admin', style: body(15, weight: FontWeight.w900))),
          MiniButton('Owner', icon: Icons.add, primary: true, onTap: () => _addOwner(context)),
        ]),
        const SizedBox(height: 6),
        Text('Only you see this. You can change the salon name any number of times.', style: body(13, color: C.mut)),
        const SizedBox(height: 10),
        if (s.ownerPhones.isEmpty) Text('No other owners yet.', style: body(14, color: C.mut)),
        for (final p in s.ownerPhones)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Row(children: [
              const Icon(Icons.phone_iphone, size: 20, color: C.mut),
              const SizedBox(width: 10),
              Expanded(child: Text(p, style: body(15, weight: FontWeight.w700))),
              MiniButton('Remove', textColor: C.bad, onTap: () async {
                try {
                  await Repo.setOwnerPhones(s.ownerPhones.where((x) => x != p).toList());
                  if (context.mounted) toast(context, '$p removed');
                } catch (_) {
                  if (context.mounted) toast(context, 'Could not save. Try again.');
                }
              }),
            ]),
          ),
        const Divider(height: 24, color: C.line),
        Row(children: [
          Expanded(
            child: Text('Owner name changes used: ${s.nameChanges} of ${SalonSettings.maxNameChanges}',
                style: body(14, weight: FontWeight.w700)),
          ),
          MiniButton('Reset', onTap: () async {
            try {
              await Repo.resetNameChanges();
              if (context.mounted) toast(context, 'Owners can change the name ${SalonSettings.maxNameChanges} more times');
            } catch (_) {
              if (context.mounted) toast(context, 'Could not reset. Try again.');
            }
          }),
        ]),
      ]),
    );
  }

  Widget _nameField() {
    final s = app.settings;
    final locked = s != null && !app.isSuper && s.nameChangesLeft <= 0;
    final helper = s == null
        ? null
        : app.isSuper
            ? 'Admin: unlimited changes'
            : (locked ? 'Locked. Only the app admin can change it.' : 'You can change the name ${s.nameChangesLeft} more times');
    return TextField(
      controller: name,
      readOnly: locked,
      decoration: InputDecoration(
        labelText: 'Salon name',
        helperText: helper,
        suffixIcon: locked ? const Icon(Icons.lock_outline, color: C.mut) : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) => SafeArea(
        bottom: false,
        child: ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 120), children: [
          Text('Settings', style: display(25)),
          const SizedBox(height: 16),
          if (app.isSuper) ...[_adminCard(context), const SizedBox(height: 14)],
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Salon', style: body(15, weight: FontWeight.w900)),
              const SizedBox(height: 12),
              _nameField(),
              const SizedBox(height: 10),
              TextField(controller: tag, decoration: const InputDecoration(labelText: 'Tagline')),
              const SizedBox(height: 10),
              TextField(controller: city, decoration: const InputDecoration(labelText: 'City')),
              const SizedBox(height: 10),
              TextField(controller: area, decoration: const InputDecoration(labelText: 'Area / address')),
              const SizedBox(height: 10),
              TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Salon phone')),
              const SizedBox(height: 14),
              Text('Currency', style: body(13, color: C.mut, weight: FontWeight.w700)),
              const SizedBox(height: 6),
              Wrap(children: [for (final c in currencies) _chip(c, cur == c, () => setState(() => cur = c))]),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: _timeBox('Opens', open, () => _pickTime(true))),
                const SizedBox(width: 10),
                Expanded(child: _timeBox('Closes', close, () => _pickTime(false))),
              ]),
              const SizedBox(height: 14),
              DarkButton(_busy ? 'Saving…' : 'Save salon details', onTap: _busy ? null : _save),
            ]),
          ),
          const SizedBox(height: 14),
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text('Services and prices', style: body(15, weight: FontWeight.w900))),
                MiniButton('Add', icon: Icons.add, primary: true, onTap: () => _editService(context, null)),
              ]),
              for (final c in cats)
                if (app.services.any((s) => s.cat == c.id)) ...[
                  Padding(padding: const EdgeInsets.fromLTRB(0, 14, 0, 4), child: Eyebrow(c.label)),
                  for (final s in app.services.where((s) => s.cat == c.id))
                    InkWell(
                      onTap: () => _editService(context, s),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 9),
                        child: Row(children: [
                          Expanded(child: Text(s.name, style: body(14.5, weight: FontWeight.w700))),
                          Text('${s.mins} min · ', style: body(13, color: C.mut)),
                          Text(app.money(s.price), style: display(13.5)),
                          const SizedBox(width: 6),
                          const Icon(Icons.edit_outlined, size: 17, color: C.mut),
                        ]),
                      ),
                    ),
                ],
            ]),
          ),
          const SizedBox(height: 14),
          AppCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text('Artists', style: body(15, weight: FontWeight.w900))),
                MiniButton('Add', icon: Icons.add, primary: true, onTap: () => _editStaff(context, null)),
              ]),
              const SizedBox(height: 6),
              for (final t in app.staff)
                InkWell(
                  onTap: () => _editStaff(context, t),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(children: [
                      Avatar(t.name, size: 38),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(t.name, style: body(14.5, weight: FontWeight.w700)),
                          Text(t.role, style: body(12.5, color: C.mut)),
                        ]),
                      ),
                      const Icon(Icons.edit_outlined, size: 17, color: C.mut),
                    ]),
                  ),
                ),
            ]),
          ),
          const SizedBox(height: 14),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
            child: Column(children: [
              ListTile(
                leading: const Icon(Icons.phone_iphone, color: C.gold2),
                title: Text('Open client app view', style: body(15, weight: FontWeight.w700)),
                subtitle: Text('See and test what your clients see', style: body(12.5, color: C.mut)),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CustomerShell(preview: true))),
              ),
              ListTile(
                leading: const Icon(Icons.logout, color: C.bad),
                title: Text('Sign out', style: body(15, weight: FontWeight.w700, color: C.bad)),
                onTap: () => signOut(context),
              ),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _timeBox(String label, String value, VoidCallback onTap) => InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: C.line)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: body(12, color: C.mut, weight: FontWeight.w700)),
            Text(t12(value), style: body(16, weight: FontWeight.w900)),
          ]),
        ),
      );

  void _editService(BuildContext context, Service? s) {
    final n = TextEditingController(text: s?.name ?? '');
    final m = TextEditingController(text: '${s?.mins ?? 30}');
    final p = TextEditingController(text: '${s?.price ?? 1000}');
    var cat = s?.cat ?? 'hair';
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => Padding(
          padding: EdgeInsets.fromLTRB(20, 0, 20, 24 + MediaQuery.of(ctx).viewInsets.bottom),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(s == null ? 'New service' : 'Edit service', style: display(22)),
            const SizedBox(height: 14),
            TextField(controller: n, decoration: const InputDecoration(labelText: 'Service name')),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(
                child: TextField(
                  controller: m,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: const InputDecoration(labelText: 'Minutes'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: p,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: InputDecoration(labelText: 'Price (${app.cur})'),
                ),
              ),
            ]),
            const SizedBox(height: 12),
            Wrap(runSpacing: 6, children: [for (final c in cats) _chip(c.label, cat == c.id, () => setS(() => cat = c.id))]),
            const SizedBox(height: 16),
            Row(children: [
              if (s != null) ...[
                Expanded(
                  child: DarkButton('Delete', color: C.soft, textColor: C.bad, onTap: () async {
                    Navigator.of(ctx).pop();
                    await Repo.deleteService(s.id);
                  }),
                ),
                const SizedBox(width: 10),
              ],
              Expanded(
                child: DarkButton('Save', onTap: () async {
                  final name = n.text.trim();
                  final mins = int.tryParse(m.text) ?? 0;
                  final price = int.tryParse(p.text) ?? -1;
                  if (name.isEmpty || mins <= 0 || price < 0) {
                    toast(context, 'Fill in name, minutes and price');
                    return;
                  }
                  Navigator.of(ctx).pop();
                  await Repo.saveService(Service(
                    id: s?.id ?? '',
                    cat: cat,
                    name: name,
                    mins: mins,
                    price: price,
                    order: s?.order ?? app.services.length + 100,
                  ));
                }),
              ),
            ]),
          ]),
        ),
      ),
    );
  }

  void _editStaff(BuildContext context, Staff? t) {
    final n = TextEditingController(text: t?.name ?? '');
    final r = TextEditingController(text: t?.role ?? 'Stylist');
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(20, 0, 20, 24 + MediaQuery.of(ctx).viewInsets.bottom),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(t == null ? 'New artist' : 'Edit artist', style: display(22)),
          const SizedBox(height: 14),
          TextField(controller: n, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Name')),
          const SizedBox(height: 10),
          TextField(controller: r, decoration: const InputDecoration(labelText: 'Role')),
          const SizedBox(height: 16),
          Row(children: [
            if (t != null) ...[
              Expanded(
                child: DarkButton('Remove', color: C.soft, textColor: C.bad, onTap: () async {
                  if (app.staff.length < 2) {
                    toast(context, 'Keep at least one artist');
                    return;
                  }
                  Navigator.of(ctx).pop();
                  await Repo.deleteStaff(t.id);
                }),
              ),
              const SizedBox(width: 10),
            ],
            Expanded(
              child: DarkButton('Save', onTap: () async {
                if (n.text.trim().isEmpty) {
                  toast(context, 'Enter a name');
                  return;
                }
                Navigator.of(ctx).pop();
                await Repo.saveStaff(Staff(
                  id: t?.id ?? '',
                  name: n.text.trim(),
                  role: r.text.trim(),
                  rate: t?.rate ?? 0,
                  order: t?.order ?? app.staff.length + 100,
                ));
              }),
            ),
          ]),
        ]),
      ),
    );
  }
}
