import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models.dart';
import '../repo.dart';
import '../state.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets.dart';
import 'booking_flow.dart';

class CustomerShell extends StatefulWidget {
  /// Set when the owner opens the client view from Settings.
  final bool preview;
  const CustomerShell({super.key, this.preview = false});

  @override
  State<CustomerShell> createState() => _CustomerShellState();
}

class _CustomerShellState extends State<CustomerShell> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: IndexedStack(index: _tab, children: [
        HomeTab(onSeeOffers: () => setState(() => _tab = 2)),
        const BookingsTab(),
        const OffersTab(),
        ProfileTab(preview: widget.preview),
      ]),
      bottomNavigationBar: FloatNav(
        items: const [
          (Icons.home_outlined, 'Home'),
          (Icons.calendar_month_outlined, 'Bookings'),
          (Icons.local_offer_outlined, 'Offers'),
          (Icons.person_outline, 'Profile'),
        ],
        index: _tab,
        onTap: (i) => setState(() => _tab = i),
      ),
    );
  }
}

(String, int?) tierFor(int p) => p >= 1500 ? ('Noor Black', null) : (p >= 500 ? ('Gold', 1500) : ('Rose', 500));

List<Booking> upcomingMine() {
  final t = todayStr();
  final l = app.mine.where((b) => (b.status == 'confirmed' || b.status == 'in') && b.date.compareTo(t) >= 0).toList();
  l.sort((a, b) => a.sortKey.compareTo(b.sortKey));
  return l;
}

// ----------------------------------------------------------------- HOME
class HomeTab extends StatefulWidget {
  final VoidCallback onSeeOffers;
  const HomeTab({super.key, required this.onSeeOffers});

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  String cat = 'hair';

  static const rituals = [
    ('Bridal makeup', 'From 3 hours', [Color(0xFF6B3348), Color(0xFF2B1520)], 0),
    ('Keratin treatment', 'Smooth for months', [Color(0xFFB0814A), Color(0xFF5E3B25)], 1),
    ('Hydra facial', 'Glass-skin glow', [Color(0xFFC77F8A), Color(0xFF7A3A4C)], 2),
    ('Mehndi (both hands)', 'Both hands', [Color(0xFF7D4F86), Color(0xFF3A1F45)], 3),
  ];

  Service? _byName(String n) {
    for (final s in app.services) {
      if (s.name == n) return s;
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final s = app.settings;
        if (s == null) return const SizedBox.shrink();
        final h = DateTime.now().hour;
        final greet = h < 12 ? 'Good morning,' : (h < 17 ? 'Good afternoon,' : 'Good evening,');
        final up = upcomingMine();
        final next = up.isEmpty ? null : up.first;
        final svcs = app.services.where((x) => x.cat == cat).toList();
        final pts = app.points;
        final (tier, nextAt) = tierFor(pts);
        return SafeArea(
          bottom: false,
          child: ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 120), children: [
            Row(children: [
              Avatar(app.userName, ring: true),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(greet, style: body(13, color: C.mut)),
                  Text(app.userName.split(' ').first, style: display(19)),
                ]),
              ),
              CircleIconButton(Icons.notifications_none, dot: true, onTap: () => _notifications(context, next)),
            ]),
            const SizedBox(height: 16),
            _hero(context, s.name),
            if (next != null) ...[
              const SizedBox(height: 14),
              AppCard(
                onTap: () => showBookingSheet(context, next),
                child: Row(children: [
                  DateBox(next.date, width: 54),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Eyebrow('Your next visit'),
                      const SizedBox(height: 2),
                      Text('${t12(next.time)} · ${next.svcNames.isEmpty ? '' : next.svcNames.first}',
                          style: body(15, weight: FontWeight.w700), maxLines: 1, overflow: TextOverflow.ellipsis),
                      Text('with ${next.staffName}', style: body(13, color: C.mut)),
                    ]),
                  ),
                  const Icon(Icons.chevron_right, color: C.mut),
                ]),
              ),
            ],
            SectionTitle('Signature rituals',
                trailing: GestureDetector(
                  onTap: widget.onSeeOffers,
                  child: Text('Offers', style: body(13, color: C.rose, weight: FontWeight.w900)),
                )),
            SizedBox(
              height: 212,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                clipBehavior: Clip.none,
                itemCount: rituals.length,
                separatorBuilder: (_, __) => const SizedBox(width: 12),
                itemBuilder: (_, i) {
                  final r = rituals[i];
                  final svc = _byName(r.$1);
                  return _ArchCard(
                    title: r.$1.replaceAll(' (both hands)', ''),
                    sub: svc == null ? r.$2 : '${r.$2} · ${app.money(svc.price)}',
                    colors: r.$3,
                    variant: r.$4,
                    onTap: () => openBookingFlow(context, sel: svc == null ? const [] : [svc.id], step: svc == null ? 0 : 1),
                  );
                },
              ),
            ),
            SectionTitle('Menu', trailing: Text('${svcs.length} services', style: body(13, color: C.mut))),
            Row(children: [
              for (final c in cats)
                Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => cat = c.id),
                    child: Column(children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 220),
                        width: 58,
                        height: 58,
                        decoration: BoxDecoration(
                          color: cat == c.id ? C.aub : Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: const [BoxShadow(color: C.line, offset: Offset(0, 1))],
                        ),
                        child: Icon(c.icon, color: cat == c.id ? C.gold : C.rose, size: 24),
                      ),
                      const SizedBox(height: 7),
                      Text(c.label, style: body(12, weight: FontWeight.w700, color: cat == c.id ? C.ink : C.mut)),
                    ]),
                  ),
                ),
            ]),
            const SizedBox(height: 14),
            AppCard(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
              child: svcs.isEmpty
                  ? const EmptyNote('No services in this category yet.', icon: Icons.spa_outlined)
                  : Column(children: [
                      for (var i = 0; i < svcs.length; i++) ...[
                        if (i > 0) const Divider(height: 1, color: C.line),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          child: Row(children: [
                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(svcs[i].name, style: body(15, weight: FontWeight.w700)),
                                Row(children: [
                                  const Icon(Icons.schedule, size: 13, color: C.mut),
                                  const SizedBox(width: 4),
                                  Text('${svcs[i].mins} min', style: body(13, color: C.mut)),
                                ]),
                              ]),
                            ),
                            Text(app.money(svcs[i].price), style: display(14.5)),
                            const SizedBox(width: 10),
                            Material(
                              color: C.soft,
                              shape: const CircleBorder(),
                              child: InkWell(
                                customBorder: const CircleBorder(),
                                onTap: () => openBookingFlow(context, sel: [svcs[i].id], step: 1),
                                child: const SizedBox(width: 36, height: 36, child: Icon(Icons.add, size: 18, color: C.rose)),
                              ),
                            ),
                          ]),
                        ),
                      ],
                    ]),
            ),
            const SizedBox(height: 22),
            _memberCard(tier, pts, nextAt),
            const SectionTitle('Our artists'),
            SizedBox(
              height: 214,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                clipBehavior: Clip.none,
                itemCount: app.staff.length,
                separatorBuilder: (_, __) => const SizedBox(width: 12),
                itemBuilder: (_, i) {
                  final t = app.staff[i];
                  return SizedBox(
                    width: 134,
                    child: AppCard(
                      padding: const EdgeInsets.fromLTRB(8, 8, 8, 12),
                      onTap: () => openBookingFlow(context, staff: t.id),
                      child: Column(children: [
                        Container(
                          height: 118,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            borderRadius: const BorderRadius.vertical(top: Radius.circular(60), bottom: Radius.circular(14)),
                            gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [avc(t.name), C.aub]),
                          ),
                          child: Text(initials(t.name), style: display(30, color: Colors.white)),
                        ),
                        const SizedBox(height: 10),
                        Text(t.name, style: body(13.5, weight: FontWeight.w700), maxLines: 1, overflow: TextOverflow.ellipsis),
                        Text(t.role, style: body(12.5, color: C.mut), maxLines: 1, overflow: TextOverflow.ellipsis),
                        Text(t.rate > 0 ? '★ ${t.rate}' : 'New', style: body(12.5, color: C.gold2, weight: FontWeight.w900)),
                      ]),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 22),
            AppCard(
              child: Row(children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(color: C.soft, borderRadius: BorderRadius.circular(14)),
                  child: const Icon(Icons.location_on_outlined, color: C.rose),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${s.area}, ${s.city}', style: body(14.5, weight: FontWeight.w700)),
                    Text('Open daily ${t12(s.open)} – ${t12(s.close)} · ${s.phone}', style: body(13, color: C.mut)),
                  ]),
                ),
              ]),
            ),
          ]),
        );
      },
    );
  }

  Widget _hero(BuildContext context, String salon) {
    return Container(
      height: 300,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(gradient: C.hero, borderRadius: BorderRadius.circular(30)),
      child: Stack(children: [
        Positioned(
          right: 30,
          top: 20,
          child: Container(
            width: 160,
            height: 160,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(colors: [Color(0x55F3DFB2), Color(0x00F3DFB2)]),
            ),
          ),
        ),
        const Positioned(right: -14, bottom: 0, child: Portrait()),
        Padding(
          padding: const EdgeInsets.all(22),
          child: FractionallySizedBox(
            widthFactor: .64,
            alignment: Alignment.topLeft,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(salon.toUpperCase(), style: body(11, color: C.gold, weight: FontWeight.w700, spacing: 3), maxLines: 2),
              const SizedBox(height: 12),
              Text('Look\ngood.', style: display(28, color: C.onDark)),
              FoilText('Feel noor.', style: display(28)),
              const Spacer(),
              GoldButton('Book appointment', icon: Icons.chevron_right, onTap: () => openBookingFlow(context)),
            ]),
          ),
        ),
      ]),
    );
  }

  Widget _memberCard(String tier, int pts, int? nextAt) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: C.foil,
        borderRadius: BorderRadius.circular(24),
        boxShadow: const [BoxShadow(color: Color(0x66A77F43), blurRadius: 36, offset: Offset(0, 18), spreadRadius: -16)],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('NOOR CIRCLE', style: body(11.5, color: C.aub, weight: FontWeight.w900, spacing: 3)),
              const SizedBox(height: 2),
              Text('$tier member', style: display(22, color: C.aub)),
            ]),
          ),
          const Icon(Icons.workspace_premium_outlined, size: 32, color: C.aub),
        ]),
        const SizedBox(height: 18),
        Row(children: [
          Expanded(child: Text('$pts points', style: body(15, color: C.aub, weight: FontWeight.w900))),
          Text(nextAt == null ? 'Top tier' : '${nextAt - pts} to ${tierFor(nextAt).$1}', style: body(13, color: C.aub)),
        ]),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: LinearProgressIndicator(
            value: nextAt == null ? 1 : (pts / nextAt).clamp(0, 1).toDouble(),
            minHeight: 6,
            backgroundColor: const Color(0x222B1520),
            color: C.aub,
          ),
        ),
        const SizedBox(height: 8),
        Text('1 point for every ${app.money(100)} spent', style: body(12.5, color: C.aub.withValues(alpha: .8))),
      ]),
    );
  }

  void _notifications(BuildContext context, Booking? next) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 28),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Notifications', style: display(22)),
          const SizedBox(height: 10),
          if (next != null)
            _note(Icons.event_outlined, 'Reminder', '${fdate(next.date)} at ${t12(next.time)} with ${next.staffName}.'),
          for (final o in app.offers.take(2)) _note(Icons.local_offer_outlined, '${o.code} is live', o.desc),
          _note(Icons.workspace_premium_outlined, '${app.points} Noor Circle points', 'Keep visiting to reach the next tier.'),
          const SizedBox(height: 14),
          DarkButton('Close', onTap: () => Navigator.of(ctx).pop()),
        ]),
      ),
    );
  }

  Widget _note(IconData i, String t, String s) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            width: 42,
            height: 42,
            decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
            child: Icon(i, color: C.gold2, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t, style: body(14.5, weight: FontWeight.w700)),
              Text(s, style: body(13.5, color: C.mut)),
            ]),
          ),
        ]),
      );
}

class _ArchCard extends StatelessWidget {
  final String title, sub;
  final List<Color> colors;
  final int variant;
  final VoidCallback onTap;
  const _ArchCard({required this.title, required this.sub, required this.colors, required this.variant, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(75),
          topRight: Radius.circular(75),
          bottomLeft: Radius.circular(24),
          bottomRight: Radius.circular(24),
        ),
        child: Container(
          width: 150,
          height: 210,
          decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: colors)),
          child: Stack(children: [
            Positioned.fill(child: CustomPaint(painter: _ArchDeco(variant))),
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.black.withValues(alpha: 0), Colors.black.withValues(alpha: .45)],
                    stops: const [.5, 1],
                  ),
                ),
              ),
            ),
            Positioned(
              left: 14,
              right: 12,
              bottom: 14,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: display(15.5, color: Colors.white)),
                const SizedBox(height: 4),
                Text(sub, style: body(12, color: Colors.white.withValues(alpha: .9))),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}

class _ArchDeco extends CustomPainter {
  final int v;
  _ArchDeco(this.v);

  @override
  void paint(Canvas canvas, Size size) {
    final gold = Paint()
      ..color = const Color(0x80F3DFB2)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;
    final white = Paint()..color = Colors.white.withValues(alpha: .13);
    final c = Offset(size.width / 2, size.height * .34);
    switch (v) {
      case 0:
        canvas.drawCircle(c, 40, gold);
        canvas.drawCircle(c.translate(0, -8), 4, Paint()..color = const Color(0xB3F3DFB2));
        canvas.drawArc(Rect.fromCircle(center: c.translate(0, 62), radius: 30), 3.4, 2.6, false, gold);
        break;
      case 1:
        for (var i = 0; i < 4; i++) {
          final x = 20.0 + i * 30;
          final p = Path()
            ..moveTo(x, 30)
            ..cubicTo(x + 30, 50, x + 30, 100, x, 130);
          canvas.drawPath(p, Paint()
            ..color = Colors.white.withValues(alpha: .35)
            ..style = PaintingStyle.stroke
            ..strokeWidth = 2);
        }
        break;
      case 2:
        canvas.drawCircle(c, 46, white);
        canvas.drawCircle(c, 28, white);
        canvas.drawCircle(c.translate(16, -16), 6, Paint()..color = Colors.white.withValues(alpha: .5));
        break;
      default:
        final p = Path()
          ..moveTo(c.dx, 26)
          ..cubicTo(c.dx - 26, 60, c.dx - 26, 100, c.dx, 130)
          ..cubicTo(c.dx + 26, 100, c.dx + 26, 60, c.dx, 26);
        canvas.drawPath(p, white);
        canvas.drawLine(Offset(c.dx, 36), Offset(c.dx, 120), gold);
    }
  }

  @override
  bool shouldRepaint(covariant _ArchDeco old) => old.v != v;
}

// ----------------------------------------------------------------- BOOKINGS
class BookingsTab extends StatefulWidget {
  const BookingsTab({super.key});

  @override
  State<BookingsTab> createState() => _BookingsTabState();
}

class _BookingsTabState extends State<BookingsTab> {
  String tab = 'up';

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final t = todayStr();
        List<Booking> list;
        if (tab == 'up') {
          list = upcomingMine();
        } else if (tab == 'past') {
          list = app.mine
              .where((b) => b.status == 'done' || b.status == 'noshow' || (b.status == 'confirmed' && b.date.compareTo(t) < 0))
              .toList()
            ..sort((a, b) => b.sortKey.compareTo(a.sortKey));
        } else {
          list = app.mine.where((b) => b.status == 'cancelled').toList()..sort((a, b) => b.sortKey.compareTo(a.sortKey));
        }
        return SafeArea(
          bottom: false,
          child: ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 120), children: [
            Row(children: [
              Expanded(child: Text('My bookings', style: display(25))),
              CircleIconButton(Icons.add, onTap: () => openBookingFlow(context)),
            ]),
            const SizedBox(height: 16),
            Row(children: [
              for (final c in const [('up', 'Upcoming'), ('past', 'Past'), ('can', 'Cancelled')])
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(c.$2),
                    selected: tab == c.$1,
                    onSelected: (_) => setState(() => tab = c.$1),
                    showCheckmark: false,
                    selectedColor: C.aub,
                    backgroundColor: Colors.white,
                    side: const BorderSide(color: C.line),
                    shape: const StadiumBorder(),
                    labelStyle: body(13, weight: FontWeight.w700, color: tab == c.$1 ? C.gold : C.ink),
                  ),
                ),
            ]),
            const SizedBox(height: 16),
            if (list.isEmpty)
              EmptyNote(
                tab == 'up' ? 'No upcoming visits. Your chair is waiting.' : 'Nothing here yet.',
                action: tab == 'up' ? GoldButton('Book a visit', onTap: () => openBookingFlow(context)) : null,
              ),
            for (final b in list) _ticket(context, b),
          ]),
        );
      },
    );
  }

  Widget _ticket(BuildContext context, Booking b) {
    Widget bottom;
    if (tab == 'up') {
      bottom = Row(children: [
        Expanded(child: MiniButton('Reschedule', onTap: () => openBookingFlow(context, resched: b))),
        const SizedBox(width: 8),
        Expanded(child: MiniButton('Cancel', textColor: C.bad, onTap: () => _confirmCancel(context, b))),
        const SizedBox(width: 8),
        Expanded(child: MiniButton('Details', primary: true, onTap: () => showBookingSheet(context, b))),
      ]);
    } else if (b.status == 'done') {
      bottom = Row(children: [
        Expanded(child: Text('+${b.total ~/ 100} points earned', style: body(13, color: C.mut))),
        MiniButton('Book again', primary: true, onTap: () => openBookingFlow(context, sel: b.svc, staff: b.staff, step: 2)),
      ]);
    } else {
      bottom = Text(app.settings?.name ?? '', style: body(13, color: C.mut));
    }
    return Ticket(
      top: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        DateBox(b.date),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(b.title, style: body(15, weight: FontWeight.w700)),
            const SizedBox(height: 2),
            Text('${t12(b.time)} · ${b.dur} min · ${b.staffName}', style: body(13, color: C.mut)),
            const SizedBox(height: 8),
            StatusChip(b.status),
          ]),
        ),
        Text(app.money(b.total), style: display(14.5)),
      ]),
      bottom: bottom,
    );
  }

  void _confirmCancel(BuildContext context, Booking b) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 28),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Cancel this visit?', style: display(22)),
          const SizedBox(height: 8),
          Text('${fdate(b.date)}, ${t12(b.time)} · ${b.title}. Free if cancelled 3 hours before.', style: body(15, color: C.mut, height: 1.4)),
          const SizedBox(height: 20),
          Row(children: [
            Expanded(child: DarkButton('Keep it', color: C.soft, textColor: C.ink, onTap: () => Navigator.of(ctx).pop())),
            const SizedBox(width: 10),
            Expanded(
              child: DarkButton('Cancel visit', color: C.bad, textColor: Colors.white, onTap: () async {
                Navigator.of(ctx).pop();
                try {
                  await Repo.setStatus(b, 'cancelled');
                  if (context.mounted) toast(context, 'Booking cancelled');
                } catch (_) {
                  if (context.mounted) toast(context, 'Could not cancel. Try again.');
                }
              }),
            ),
          ]),
        ]),
      ),
    );
  }
}

// ----------------------------------------------------------------- OFFERS
class OffersTab extends StatelessWidget {
  const OffersTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) => SafeArea(
        bottom: false,
        child: ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 120), children: [
          Text('Offers', style: display(25)),
          const SizedBox(height: 6),
          Text('Apply the code when you check out.', style: body(14, color: C.mut)),
          const SizedBox(height: 16),
          if (app.offers.isEmpty) const EmptyNote('No offers right now. Check back soon.', icon: Icons.local_offer_outlined),
          for (final o in app.offers)
            Container(
              margin: const EdgeInsets.only(bottom: 14),
              clipBehavior: Clip.antiAlias,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22),
                boxShadow: const [BoxShadow(color: Color(0x222B1520), blurRadius: 30, offset: Offset(0, 10), spreadRadius: -14)],
              ),
              child: IntrinsicHeight(
                child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  Container(
                    width: 94,
                    color: C.aub,
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text(o.pct > 0 ? '${o.pct}%' : app.cur, style: display(28, color: C.gold)),
                      Text(o.pct > 0 ? 'OFF' : '${o.flat} OFF', style: body(11, color: C.gold, weight: FontWeight.w900, spacing: 1)),
                    ]),
                  ),
                  Expanded(
                    child: Container(
                      color: Colors.white,
                      padding: const EdgeInsets.all(14),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(o.pct > 0 ? '${o.pct}% off your visit' : '${app.money(o.flat)} off', style: body(15, weight: FontWeight.w900)),
                        const SizedBox(height: 2),
                        Text('${o.desc}${o.pct > 0 && o.cap > 0 ? ' · up to ${app.money(o.cap)}' : ''}', style: body(13, color: C.mut)),
                        const SizedBox(height: 10),
                        Row(children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: C.gold2, width: 1.4),
                            ),
                            child: Text(o.code, style: body(13, color: C.gold2, weight: FontWeight.w900, spacing: 1.5)),
                          ),
                          const Spacer(),
                          MiniButton('Copy', primary: true, onTap: () {
                            Clipboard.setData(ClipboardData(text: o.code));
                            toast(context, 'Code copied');
                          }),
                        ]),
                      ]),
                    ),
                  ),
                ]),
              ),
            ),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(gradient: C.foil, borderRadius: BorderRadius.circular(22)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Bring a friend', style: display(20, color: C.aub)),
              const SizedBox(height: 6),
              Text('Share FRIEND500. When she finishes her first visit, you both save ${app.money(500)}.',
                  style: body(14, color: C.aub, height: 1.4)),
            ]),
          ),
        ]),
      ),
    );
  }
}

// ----------------------------------------------------------------- PROFILE
class ProfileTab extends StatefulWidget {
  final bool preview;
  const ProfileTab({super.key, this.preview = false});

  @override
  State<ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<ProfileTab> {
  late final _name = TextEditingController(text: app.userName);
  bool _busy = false;

  Future<void> _save() async {
    final n = _name.text.trim();
    if (n.length < 2) {
      toast(context, 'Enter your name');
      return;
    }
    setState(() => _busy = true);
    try {
      await Repo.saveUser(app.uid, n, app.userPhone);
      if (mounted) toast(context, 'Profile saved');
    } catch (_) {
      if (mounted) toast(context, 'Could not save. Try again.');
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final done = app.mine.where((b) => b.status == 'done').length;
        final pts = app.points;
        return SafeArea(
          bottom: false,
          child: ListView(padding: const EdgeInsets.fromLTRB(18, 18, 18, 120), children: [
            Center(child: Avatar(app.userName, size: 84, ring: true)),
            const SizedBox(height: 12),
            Center(child: Text(app.userName, style: display(24))),
            Center(child: Text('${app.userPhone} · ${tierFor(pts).$1} member', style: body(13.5, color: C.mut))),
            const SizedBox(height: 18),
            Row(children: [
              _stat('Visits', '$done'),
              const SizedBox(width: 10),
              _stat('Points', '$pts'),
              const SizedBox(width: 10),
              _stat('Upcoming', '${upcomingMine().length}'),
            ]),
            const SizedBox(height: 14),
            AppCard(
              child: Column(children: [
                TextField(controller: _name, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Full name')),
                const SizedBox(height: 12),
                DarkButton(_busy ? 'Saving…' : 'Save changes', onTap: _busy ? null : _save),
              ]),
            ),
            const SizedBox(height: 14),
            AppCard(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
              child: Column(children: [
                if (widget.preview)
                  ListTile(
                    leading: const Icon(Icons.storefront_outlined, color: C.gold2),
                    title: Text('Back to owner dashboard', style: body(15, weight: FontWeight.w700)),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.of(context).pop(),
                  ),
                ListTile(
                  leading: const Icon(Icons.call_outlined, color: C.rose),
                  title: Text('Call the salon', style: body(15, weight: FontWeight.w700)),
                  subtitle: Text(app.settings?.phone ?? '', style: body(13, color: C.mut)),
                ),
                ListTile(
                  leading: const Icon(Icons.logout, color: C.bad),
                  title: Text('Sign out', style: body(15, weight: FontWeight.w700, color: C.bad)),
                  onTap: () => signOut(context),
                ),
              ]),
            ),
          ]),
        );
      },
    );
  }

  Widget _stat(String l, String v) => Expanded(
        child: AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(l, style: body(12.5, color: C.mut)),
            Text(v, style: display(20)),
          ]),
        ),
      );
}
