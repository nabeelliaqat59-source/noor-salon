import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../repo.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

/// Phone number + one-time code sign-in.
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _phone = TextEditingController();
  final _code = TextEditingController();
  String? _verificationId;
  int? _resendToken;
  bool _busy = false;
  String _error = '';

  String get _e164 {
    var d = _phone.text.replaceAll(RegExp(r'\D'), '');
    if (d.startsWith('92')) d = d.substring(2);
    if (d.startsWith('0')) d = d.substring(1);
    return '+92$d';
  }

  Future<void> _send() async {
    final digits = _e164.substring(3);
    if (digits.length != 10) {
      setState(() => _error = 'Enter your 10-digit mobile number, like 300 1234567');
      return;
    }
    setState(() {
      _busy = true;
      _error = '';
    });
    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: _e164,
      forceResendingToken: _resendToken,
      timeout: const Duration(seconds: 60),
      verificationCompleted: (cred) async {
        // Android can read the SMS automatically.
        await FirebaseAuth.instance.signInWithCredential(cred);
      },
      verificationFailed: (e) {
        if (!mounted) return;
        setState(() {
          _busy = false;
          _error = e.code == 'too-many-requests'
              ? 'Too many tries. Wait a little and try again.'
              : (e.message ?? 'Could not send the code. Check the number.');
        });
      },
      codeSent: (id, token) {
        if (!mounted) return;
        setState(() {
          _verificationId = id;
          _resendToken = token;
          _busy = false;
        });
      },
      codeAutoRetrievalTimeout: (id) => _verificationId = id,
    );
  }

  Future<void> _verify() async {
    if (_code.text.trim().length != 6) {
      setState(() => _error = 'Enter the 6-digit code');
      return;
    }
    setState(() {
      _busy = true;
      _error = '';
    });
    try {
      final cred = PhoneAuthProvider.credential(verificationId: _verificationId!, smsCode: _code.text.trim());
      await FirebaseAuth.instance.signInWithCredential(cred);
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = e.code == 'invalid-verification-code' ? 'That code is not right. Try again.' : (e.message ?? 'Sign-in failed');
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final codeStep = _verificationId != null;
    return Scaffold(
      backgroundColor: C.aub,
      body: Container(
        decoration: const BoxDecoration(gradient: C.hero),
        child: SafeArea(
          child: ListView(padding: const EdgeInsets.fromLTRB(24, 20, 24, 24), children: [
            const Align(alignment: Alignment.centerRight, child: Portrait(width: 170, height: 204)),
            Text('NOOR BEAUTY LOUNGE', style: body(12, color: C.gold, weight: FontWeight.w700, spacing: 3)),
            const SizedBox(height: 10),
            Text(codeStep ? 'Enter your code' : 'Welcome,\nbeautiful.', style: display(32, color: C.onDark)),
            const SizedBox(height: 8),
            Text(
              codeStep ? 'We sent a 6-digit code to $_e164' : 'Sign in with your mobile number to book and manage your visits.',
              style: body(15, color: C.onDarkMut),
            ),
            const SizedBox(height: 26),
            if (!codeStep)
              TextField(
                controller: _phone,
                keyboardType: TextInputType.phone,
                autofillHints: const [AutofillHints.telephoneNumber],
                inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9 ]'))],
                style: body(18, weight: FontWeight.w700),
                decoration: InputDecoration(
                  prefixIcon: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 8, 0),
                    child: Center(widthFactor: 1, child: Text('+92', style: body(18, weight: FontWeight.w700, color: C.mut))),
                  ),
                  hintText: '300 1234567',
                ),
                onSubmitted: (_) => _send(),
              )
            else
              TextField(
                controller: _code,
                keyboardType: TextInputType.number,
                autofillHints: const [AutofillHints.oneTimeCode],
                maxLength: 6,
                textAlign: TextAlign.center,
                style: display(26, spacing: 10),
                decoration: const InputDecoration(counterText: '', hintText: '••••••'),
                onSubmitted: (_) => _verify(),
              ),
            if (_error.isNotEmpty) ...[
              const SizedBox(height: 10),
              Text(_error, style: body(13.5, color: const Color(0xFFFFB3BA), weight: FontWeight.w700)),
            ],
            const SizedBox(height: 18),
            GoldButton(
              _busy ? 'Please wait…' : (codeStep ? 'Verify and continue' : 'Send code'),
              expand: true,
              onTap: _busy ? null : (codeStep ? _verify : _send),
            ),
            if (codeStep)
              TextButton(
                onPressed: _busy
                    ? null
                    : () => setState(() {
                          _verificationId = null;
                          _code.clear();
                        }),
                child: Text('Change number', style: body(14, color: C.gold, weight: FontWeight.w700)),
              ),
          ]),
        ),
      ),
    );
  }
}

/// First time only: ask the client's name.
class ProfileSetupScreen extends StatefulWidget {
  const ProfileSetupScreen({super.key});

  @override
  State<ProfileSetupScreen> createState() => _ProfileSetupScreenState();
}

class _ProfileSetupScreenState extends State<ProfileSetupScreen> {
  final _name = TextEditingController();
  bool _busy = false;
  String _error = '';

  Future<void> _save() async {
    final n = _name.text.trim();
    if (n.length < 2) {
      setState(() => _error = 'Enter your name');
      return;
    }
    setState(() => _busy = true);
    try {
      await Repo.saveUser(app.uid, n, app.authPhone);
    } catch (e) {
      if (mounted) {
        setState(() {
          _busy = false;
          _error = 'Could not save. Check your internet and try again.';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.all(24), children: [
          const SizedBox(height: 40),
          const Eyebrow('One last thing'),
          const SizedBox(height: 8),
          Text('What should we\ncall you?', style: display(30)),
          const SizedBox(height: 24),
          TextField(
            controller: _name,
            textCapitalization: TextCapitalization.words,
            autofillHints: const [AutofillHints.name],
            decoration: const InputDecoration(labelText: 'Full name'),
            onSubmitted: (_) => _save(),
          ),
          if (_error.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_error, style: body(13, color: C.bad))),
          const SizedBox(height: 20),
          DarkButton(_busy ? 'Saving…' : 'Continue', onTap: _busy ? null : _save),
        ]),
      ),
    );
  }
}

/// Shown when no salon exists yet. Whoever completes it becomes the owner.
class SetupSalonScreen extends StatefulWidget {
  const SetupSalonScreen({super.key});

  @override
  State<SetupSalonScreen> createState() => _SetupSalonScreenState();
}

class _SetupSalonScreenState extends State<SetupSalonScreen> {
  bool _busy = false;

  Future<void> _go() async {
    setState(() => _busy = true);
    try {
      await Repo.setupSalon(app.uid);
    } catch (e) {
      if (!mounted) return;
      setState(() => _busy = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Setup failed: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: C.hero),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Spacer(),
              Text('SALON OWNER', style: body(12, color: C.gold, weight: FontWeight.w700, spacing: 3)),
              const SizedBox(height: 10),
              Text('Set up your salon', style: display(30, color: C.onDark)),
              const SizedBox(height: 10),
              Text(
                'No salon is set up yet. Tap below and you become its owner. We add a starter menu, four artists and two offers. You can change all of it later in Settings.',
                style: body(15, color: C.onDarkMut, height: 1.5),
              ),
              const SizedBox(height: 28),
              GoldButton(_busy ? 'Setting up…' : 'Set up my salon', expand: true, onTap: _busy ? null : _go),
              const SizedBox(height: 12),
              Center(
                child: TextButton(
                  onPressed: () => FirebaseAuth.instance.signOut(),
                  child: Text('Sign out', style: body(14, color: C.onDarkMut, weight: FontWeight.w700)),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
