import 'package:flutter/material.dart';
import '../models.dart';
import '../repo.dart';
import '../state.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets.dart';

Future<void> openBookingFlow(
  BuildContext context, {
  List<String> sel = const [],
  String staff = 'any',
  int step = 0,
  Booking? resched,
  bool walkIn = false,
  String? date,
}) {
  return Navigator.of(context).push(MaterialPageRoute(
    fullscreenDialog: true,
    builder: (_) => BookingFlow(sel: sel, staff: staff, step: step, resched: resched, walkIn: walkIn, date: date),
  ));
}

/// Four steps: services, artist, date and time, review and pay.
/// Rescheduling jumps straight to date and time.
class BookingFlow extends StatefulWidget {
  final List<String> sel;
  final String staff;
  final int step;
  final Booking? resched;
  final bool walkIn;
  final String? date;
  const BookingFlow({super.key, this.sel = const [], this.staff = 'any', this.step = 0, this.resched, this.walkIn = false, this.date});

  @override
  State<BookingFlow> createState() => _BookingFlowState();
}

class _BookingFlowState extends State<BookingFlow> {
  late int step;
  late List<String> sel;
  late String staffId;
  late String date;
  String? time;
  String? resolvedStaff;
  String pay = 'cash';
  String promo = '';
  bool busy = false;
  final promoCtrl = TextEditingController();
  final nameCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();
  Stream<Map<String, String>>? _locks;
  String _locksDate = '';

  bool get isResched => widget.resched != null;

  @override
  void initState() {
    super.initState();
    final r = widget.resched;
    step = r != null ? 2 : widget.step;
    sel = r != null ? [...r.svc] : widget.sel.where((id) => app.svc(id) != null).toList();
    staffId = r != null ? r.staff : widget.staff;
    final today = todayStr();
    date = widget.date ?? (r != null && r.date.compareTo(today) >= 0 ? r.date : today);
    if (date.compareTo(today) < 0) date = today;
  }

  @override
  void dispose() {
    promoCtrl.dispose();
    nameCtrl.dispose();
    phoneCtrl.dispose();
    super.dispose();
  }

  int get dur => isResched ? widget.resched!.dur : sel.fold<int>(0, (a, id) => a + (app.svc(id)?.mins ?? 0));
  int get gross => sel.fold<int>(0, (a, id) => a + (app.svc(id)?.price ?? 0));

  Stream<Map<String, String>> locksStream() {
    if (_locks == null || _locksDate != date) {
      _locksDate = date;
      _locks = Repo.locksOn(date);
    }
    return _locks!;
  }

  (int, String) promoResult() {
    if (promo.isEmpty) return (0, '');
    Offer? o;
    for (final x in app.offers) {
      if (x.code == promo) o = x;
    }
    if (o == null) return (0, 'This code is not valid');
    final d = pdate(date);
    if (o.days.isNotEmpty && !o.days.contains(d.weekday)) return (0, 'Not valid on ${dayName(d)}');
    if (o.before.isNotEmpty && (time == null || toMins(time!) >= toMins(o.before))) {
      return (0, 'Valid only before ${t12(o.before)}');
    }
    if (gross < o.min) return (0, 'Needs a bill above ${app.money(o.min)}');
    var disc = o.pct > 0 ? (gross * o.pct / 100).round() : o.flat;
    if (o.cap > 0 && disc > o.cap) disc = o.cap;
    return (disc, '${o.code} applied');
  }

  List<String> allSlots() {
    final s = app.settings!;
    final o = toMins(s.open), c = toMins(s.close);
    return [for (var m = o; m <= c - 30; m += 30) fromMins(m)];
  }

  bool _freeFor(String sid, int start, Map<String, String> locks) {
    if (start + dur > toMins(app.settings!.close)) return false;
    for (final id in Repo.lockIds(date, sid, fromMins(start), dur)) {
      final b = locks[id];
      if (b != null && b != widget.resched?.id) return false;
    }
    return true;
  }

  String? freeStaff(String t, Map<String, String> locks) {
    final start = toMins(t);
    if (date == todayStr() && start <= nowMins()) return null;
    final ids = staffId == 'any' ? app.staff.map((s) => s.id).toList() : [staffId];
    for (final id in ids) {
      if (_freeFor(id, start, locks)) return id;
    }
    return null;
  }

  void back() {
    if (step == 0 || isResched) {
      Navigator.of(context).pop();
    } else {
      setState(() => step--);
    }
  }

  void next() => setState(() => step++);

  bool get walkInValid => !widget.walkIn || (nameCtrl.text.trim().length >= 2 && phoneCtrl.text.trim().length >= 7);

  Future<void> confirm() async {
    final sid = resolvedStaff ?? (staffId == 'any' ? '' : staffId);
    if (time == null || sid.isEmpty) return;
    final sName = app.stf(sid)?.name ?? 'Artist';
    setState(() => busy = true);
    try {
      late Booking result;
      if (isResched) {
        await Repo.reschedule(widget.resched!, date, time!, sid, sName);
        result = widget.resched!.copyWith(date: date, time: time, staff: sid, staffName: sName);
      } else {
        final (disc, _) = promoResult();
        final w = widget.walkIn;
        final b = Booking(
          uid: w ? 'walkin' : app.uid,
          cust: w ? nameCtrl.text.trim() : app.userName,
          phone: w ? phoneCtrl.text.trim() : app.userPhone,
          svc: sel,
          svcNames: sel.map((id) => app.svc(id)?.name ?? '').toList(),
          staff: sid,
          staffName: sName,
          date: date,
          time: time!,
          dur: dur,
          gross: gross,
          disc: disc,
          pay: pay,
        );
        final id = await Repo.createBooking(b);
        result = b.copyWith(id: id);
      }
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (_) => ConfirmationScreen(booking: result, moved: isResched, walkIn: widget.walkIn),
      ));
    } on SlotTakenException {
      if (!mounted) return;
      setState(() {
        busy = false;
        step = 2;
        time = null;
        resolvedStaff = null;
      });
      toast(context, 'That time was just booked by someone else. Pick another.');
    } catch (e) {
      if (!mounted) return;
      setState(() => busy = false);
      toast(context, 'Could not save. Check your internet and try again.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final titles = ['Choose services', 'Choose your artist', isResched ? 'Pick a new time' : 'Date & time', 'Review & pay'];
        return Scaffold(
          body: SafeArea(
            child: Column(children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 8, 18, 8),
                child: Row(children: [
                  CircleIconButton(step == 0 || isResched ? Icons.close : Icons.arrow_back, onTap: back),
                  const SizedBox(width: 12),
                  Expanded(child: Text(titles[step], style: display(20))),
                  if (widget.walkIn)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(color: C.soft, borderRadius: BorderRadius.circular(99)),
                      child: Text('Walk-in', style: body(12, color: C.rose, weight: FontWeight.w700)),
                    ),
                ]),
              ),
              if (!isResched)
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 2, 18, 10),
                  child: Row(children: [
                    for (var i = 0; i < 4; i++)
                      Expanded(
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 300),
                          height: 3,
                          margin: EdgeInsets.only(right: i < 3 ? 6 : 0),
                          decoration: BoxDecoration(
                            gradient: i <= step ? C.foil : null,
                            color: i <= step ? null : C.line,
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      ),
                  ]),
                ),
              Expanded(
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 280),
                  child: KeyedSubtree(key: ValueKey(step), child: _body()),
                ),
              ),
              Container(
                padding: const EdgeInsets.fromLTRB(18, 12, 18, 16),
                decoration: const BoxDecoration(
                  color: C.blush,
                  boxShadow: [BoxShadow(color: Color(0x1A2B1520), blurRadius: 24, offset: Offset(0, -10), spreadRadius: -18)],
                ),
                child: _footer(),
              ),
            ]),
          ),
        );
      },
    );
  }

  Widget _footer() {
    if (busy) return const DarkButton('Saving…');
    switch (step) {
      case 0:
        return DarkButton(
          sel.isEmpty ? 'Select a service' : 'Continue · ${sel.length} selected · ${app.money(gross)}',
          onTap: sel.isEmpty ? null : next,
        );
      case 1:
        return DarkButton('Continue', onTap: next);
      case 2:
        return DarkButton(isResched ? 'Confirm new time' : 'Continue',
            onTap: time == null ? null : (isResched ? confirm : next));
      default:
        final (disc, _) = promoResult();
        return GoldButton('Confirm · ${app.money(gross - disc)}', expand: true, onTap: walkInValid ? confirm : null);
    }
  }

  Widget _body() {
    switch (step) {
      case 0:
        return _servicesStep();
      case 1:
        return _artistStep();
      case 2:
        return _timeStep();
      default:
        return _reviewStep();
    }
  }

  Widget _servicesStep() {
    return ListView(padding: const EdgeInsets.fromLTRB(18, 4, 18, 18), children: [
      for (final c in cats)
        if (app.services.any((s) => s.cat == c.id)) ...[
          Padding(padding: const EdgeInsets.fromLTRB(2, 14, 0, 8), child: Eyebrow(c.label)),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
            child: Column(children: [
              for (final s in app.services.where((s) => s.cat == c.id))
                InkWell(
                  onTap: () => setState(() {
                    if (sel.contains(s.id)) {
                      sel.remove(s.id);
                    } else {
                      sel.add(s.id);
                    }
                  }),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: Row(children: [
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(s.name, style: body(15, weight: FontWeight.w700)),
                          Text('${s.mins} min', style: body(13, color: C.mut)),
                        ]),
                      ),
                      Text(app.money(s.price), style: display(14.5)),
                      const SizedBox(width: 10),
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        width: 34,
                        height: 34,
                        decoration: BoxDecoration(color: sel.contains(s.id) ? C.aub : C.soft, shape: BoxShape.circle),
                        child: Icon(sel.contains(s.id) ? Icons.check : Icons.add, size: 18, color: sel.contains(s.id) ? C.gold : C.rose),
                      ),
                    ]),
                  ),
                ),
            ]),
          ),
        ],
    ]);
  }

  Widget _artistStep() {
    return ListView(padding: const EdgeInsets.fromLTRB(18, 4, 18, 18), children: [
      RadioTile(
        selected: staffId == 'any',
        leading: Container(
          width: 44,
          height: 44,
          decoration: const BoxDecoration(color: C.aub, shape: BoxShape.circle),
          child: const Icon(Icons.auto_awesome, color: C.gold, size: 20),
        ),
        title: 'Any available artist',
        subtitle: 'Earliest open slot',
        onTap: () => setState(() {
          staffId = 'any';
          time = null;
        }),
      ),
      for (final s in app.staff)
        RadioTile(
          selected: staffId == s.id,
          leading: Avatar(s.name),
          title: s.name,
          subtitle: '${s.role}${s.rate > 0 ? ' · ★ ${s.rate}' : ''}',
          onTap: () => setState(() {
            staffId = s.id;
            time = null;
          }),
        ),
    ]);
  }

  Widget _timeStep() {
    final days = [for (var i = 0; i < 14; i++) ymd(dayFromToday(i))];
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SizedBox(
        height: 88,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 4),
          itemCount: days.length,
          separatorBuilder: (_, __) => const SizedBox(width: 8),
          itemBuilder: (_, i) {
            final d = pdate(days[i]);
            final on = days[i] == date;
            return GestureDetector(
              onTap: () => setState(() {
                date = days[i];
                time = null;
                resolvedStaff = null;
              }),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: 60,
                decoration: BoxDecoration(
                  color: on ? C.aub : Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: on ? C.aub : C.line),
                ),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text(i == 0 ? 'Today' : dayName(d), style: body(11, color: on ? C.gold : C.mut, weight: FontWeight.w700)),
                  Text('${d.day}', style: display(21, color: on ? C.onDark : C.ink)),
                  Text(monName(d), style: body(11, color: on ? C.gold : C.mut, weight: FontWeight.w700)),
                ]),
              ),
            );
          },
        ),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(20, 6, 20, 0),
        child: Text('$dur min · ${staffId == 'any' ? 'Any artist' : (app.stf(staffId)?.name ?? '')}', style: body(13, color: C.mut)),
      ),
      Expanded(
        child: StreamBuilder<Map<String, String>>(
          stream: locksStream(),
          builder: (context, snap) {
            if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: C.gold2));
            final locks = snap.data!;
            final slots = allSlots();
            final groups = [
              ('Morning', Icons.wb_twilight, slots.where((t) => toMins(t) < 720).toList()),
              ('Afternoon', Icons.wb_sunny_outlined, slots.where((t) => toMins(t) >= 720 && toMins(t) < 1020).toList()),
              ('Evening', Icons.nightlight_outlined, slots.where((t) => toMins(t) >= 1020).toList()),
            ];
            final anyFree = slots.any((t) => freeStaff(t, locks) != null);
            return LayoutBuilder(builder: (context, box) {
              final w = (box.maxWidth - 36 - 16) / 3;
              return ListView(padding: const EdgeInsets.fromLTRB(18, 4, 18, 18), children: [
                if (!anyFree) const EmptyNote('Fully booked on this day. Try another date.', icon: Icons.event_busy_outlined),
                for (final g in groups)
                  if (g.$3.isNotEmpty) ...[
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 16, 0, 8),
                      child: Row(children: [
                        Icon(g.$2, size: 16, color: C.mut),
                        const SizedBox(width: 6),
                        Text(g.$1, style: body(12.5, color: C.mut, weight: FontWeight.w700)),
                      ]),
                    ),
                    Wrap(spacing: 8, runSpacing: 8, children: [
                      for (final t in g.$3) _slot(t, w, freeStaff(t, locks)),
                    ]),
                  ],
              ]);
            });
          },
        ),
      ),
    ]);
  }

  Widget _slot(String t, double w, String? free) {
    final on = time == t;
    final ok = free != null;
    return GestureDetector(
      onTap: ok
          ? () => setState(() {
                time = t;
                resolvedStaff = free;
              })
          : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        width: w,
        height: 46,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          gradient: on ? C.foil : null,
          color: on ? null : (ok ? Colors.white : C.soft),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: on ? Colors.transparent : C.line),
        ),
        child: Text(
          t12(t),
          style: body(13.5, weight: FontWeight.w700, color: ok ? C.ink : C.mut.withValues(alpha: .5))
              .copyWith(decoration: ok ? null : TextDecoration.lineThrough),
        ),
      ),
    );
  }

  Widget _reviewStep() {
    final (disc, msg) = promoResult();
    final sName = app.stf(resolvedStaff ?? staffId)?.name ?? 'Any artist';
    return ListView(padding: const EdgeInsets.fromLTRB(18, 4, 18, 18), children: [
      if (widget.walkIn)
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: AppCard(
            child: Column(children: [
              TextField(
                controller: nameCtrl,
                textCapitalization: TextCapitalization.words,
                decoration: const InputDecoration(labelText: 'Client name'),
                onChanged: (_) => setState(() {}),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: phoneCtrl,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'Mobile', hintText: '03xx-xxxxxxx'),
                onChanged: (_) => setState(() {}),
              ),
            ]),
          ),
        ),
      Ticket(
        top: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          DateBox(date),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(app.settings?.name ?? '', style: display(16)),
              const SizedBox(height: 4),
              Text('${t12(time ?? '00:00')} · $dur min · $sName', style: body(13, color: C.mut)),
            ]),
          ),
        ]),
        bottom: Column(children: [
          for (final id in sel) _line(app.svc(id)?.name ?? '', app.money(app.svc(id)?.price ?? 0)),
          if (disc > 0) _line('Discount', '− ${app.money(disc)}', color: C.ok),
          const Divider(height: 18, color: C.line),
          Row(children: [
            Expanded(child: Text('Total', style: body(17, weight: FontWeight.w900))),
            Text(app.money(gross - disc), style: display(18)),
          ]),
        ]),
      ),
      Row(children: [
        Expanded(
          child: TextField(
            controller: promoCtrl,
            textCapitalization: TextCapitalization.characters,
            decoration: const InputDecoration(hintText: 'Promo code'),
            onSubmitted: (_) => setState(() => promo = promoCtrl.text.trim().toUpperCase()),
          ),
        ),
        const SizedBox(width: 8),
        SizedBox(
          height: 50,
          child: MiniButton('Apply', primary: true, onTap: () => setState(() => promo = promoCtrl.text.trim().toUpperCase())),
        ),
      ]),
      if (msg.isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Text(msg, style: body(13, color: disc > 0 ? C.ok : C.bad, weight: FontWeight.w700)),
        ),
      const Padding(padding: EdgeInsets.fromLTRB(2, 18, 0, 8), child: Eyebrow('Payment')),
      for (final e in payMethods.entries)
        RadioTile(
          selected: pay == e.key,
          leading: PayBadge(e.key),
          title: e.value.label,
          onTap: () => setState(() => pay = e.key),
        ),
      Text(
        pay == 'cash'
            ? 'Pay at the counter after your service. Free cancellation up to 3 hours before.'
            : 'The salon will send you its ${payOf(pay).label} details to pay. Free cancellation up to 3 hours before.',
        style: body(13, color: C.mut, height: 1.4),
      ),
    ]);
  }

  Widget _line(String a, String b, {Color color = C.ink}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(children: [
          Expanded(child: Text(a, style: body(14, color: color))),
          Text(b, style: body(14, color: color, weight: FontWeight.w700)),
        ]),
      );
}

/// Celebration screen with a ticket.
class ConfirmationScreen extends StatelessWidget {
  final Booking booking;
  final bool moved;
  final bool walkIn;
  const ConfirmationScreen({super.key, required this.booking, this.moved = false, this.walkIn = false});

  @override
  Widget build(BuildContext context) {
    final b = booking;
    return Scaffold(
      backgroundColor: C.aub,
      body: Stack(children: [
        Container(
          decoration: const BoxDecoration(
            gradient: RadialGradient(center: Alignment(0, -.8), radius: 1.1, colors: [Color(0xFF5A2A3E), C.aub], stops: [0, .7]),
          ),
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(children: [
              const Spacer(),
              Container(
                width: 78,
                height: 78,
                decoration: const BoxDecoration(gradient: C.foil, shape: BoxShape.circle),
                child: const Icon(Icons.check_rounded, size: 40, color: C.aub),
              ),
              const SizedBox(height: 16),
              Text(moved ? 'All moved.' : 'You’re booked.', style: display(30, color: C.onDark)),
              const SizedBox(height: 6),
              Text(
                walkIn ? 'Added to today’s book for ${b.cust.split(' ').first}.' : 'We can’t wait to see you.',
                style: body(15, color: C.onDarkMut),
              ),
              const SizedBox(height: 24),
              Ticket(
                notch: C.aub,
                top: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  DateBox(b.date),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(b.title, style: body(15, weight: FontWeight.w700)),
                      const SizedBox(height: 2),
                      Text('${t12(b.time)} · ${b.staffName}', style: body(13, color: C.mut)),
                      Text(payOf(b.pay).label, style: body(13, color: C.mut)),
                    ]),
                  ),
                  Text(app.money(b.total), style: display(14.5)),
                ]),
                bottom: Row(children: [
                  SizedBox(width: 150, height: 34, child: CustomPaint(painter: _BarcodePainter(b.id))),
                  const Spacer(),
                  Text(b.ref, style: body(13, weight: FontWeight.w900)),
                ]),
              ),
              const Spacer(),
              GoldButton('Done', expand: true, onTap: () => Navigator.of(context).pop()),
            ]),
          ),
        ),
        const Positioned.fill(child: Confetti()),
      ]),
    );
  }
}

class _BarcodePainter extends CustomPainter {
  final String seed;
  _BarcodePainter(this.seed);

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = C.ink;
    var x = 0.0;
    var i = 0;
    final codes = seed.isEmpty ? [7] : seed.codeUnits;
    while (x < size.width) {
      final w = 1.0 + (codes[i % codes.length] + i) % 3;
      canvas.drawRect(Rect.fromLTWH(x, 0, w, size.height), p);
      x += w + 2 + (codes[(i + 1) % codes.length] % 3);
      i++;
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Bottom sheet with full booking details.
void showBookingSheet(BuildContext context, Booking b) {
  final s = app.settings;
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 28),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: Text(b.ref, style: display(22))), StatusChip(b.status)]),
        const SizedBox(height: 14),
        _kv('When', '${fdate(b.date)}, ${t12(b.time)}'),
        _kv('Artist', b.staffName),
        _kv('Duration', '${b.dur} min'),
        for (final n in b.svcNames) _kv(n, ''),
        if (b.disc > 0) _kv('Discount', '− ${app.money(b.disc)}'),
        const Divider(color: C.line, height: 20),
        Row(children: [
          Expanded(child: Text('Total', style: body(17, weight: FontWeight.w900))),
          Text(app.money(b.total), style: display(18)),
        ]),
        _kv('Payment', '${payOf(b.pay).label}${b.paid ? ' · Paid' : ''}'),
        if (s != null) ...[
          const SizedBox(height: 12),
          AppCard(
            child: Row(children: [
              const Icon(Icons.location_on_outlined, color: C.rose),
              const SizedBox(width: 10),
              Expanded(
                child: Text('${s.name}, ${s.area}, ${s.city}\nCall ${s.phone}', style: body(13.5, height: 1.4)),
              ),
            ]),
          ),
        ],
        const SizedBox(height: 16),
        DarkButton('Close', onTap: () => Navigator.of(ctx).pop()),
      ]),
    ),
  );
}

Widget _kv(String k, String v) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: Text(k, style: body(14, color: v.isEmpty ? C.ink : C.mut))),
        if (v.isNotEmpty) Flexible(child: Text(v, textAlign: TextAlign.right, style: body(14, weight: FontWeight.w700))),
      ]),
    );
