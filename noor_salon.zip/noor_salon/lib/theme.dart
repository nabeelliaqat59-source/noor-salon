import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Brand colours: aubergine, blush paper and champagne gold.
class C {
  static const aub = Color(0xFF2B1520);
  static const aub2 = Color(0xFF4A2434);
  static const plum = Color(0xFF6B3348);
  static const blush = Color(0xFFFAF4F2);
  static const soft = Color(0xFFF4E4E2);
  static const rose = Color(0xFFB85F6C);
  static const gold = Color(0xFFD6B679);
  static const gold2 = Color(0xFFA77F43);
  static const ink = Color(0xFF2B1520);
  static const mut = Color(0xFF8B7179);
  static const line = Color(0xFFEEDCD9);
  static const navText = Color(0xFFC7A9B3);
  static const onDark = Color(0xFFF7E9EC);
  static const onDarkMut = Color(0xFFD8BFC8);
  static const ok = Color(0xFF3A9F73);
  static const warn = Color(0xFFC98A1B);
  static const bad = Color(0xFFC84A56);

  static const foil = LinearGradient(
    begin: Alignment(-1, -0.6),
    end: Alignment(1, 0.6),
    colors: [Color(0xFFF3DFB2), Color(0xFFC9A15E), Color(0xFFFBEDC9), Color(0xFFB88B49), Color(0xFFE9CF98)],
    stops: [0, .28, .5, .74, 1],
  );

  static const hero = RadialGradient(
    center: Alignment(0.75, -0.7),
    radius: 1.3,
    colors: [plum, aub2, aub],
    stops: [0, .4, .85],
  );
}

/// Cinzel: the salon's "royal" display lettering.
TextStyle display(double size, {Color color = C.ink, FontWeight weight = FontWeight.w600, double height = 1.12, double spacing = 0}) =>
    GoogleFonts.cinzel(fontSize: size, color: color, fontWeight: weight, height: height, letterSpacing: spacing);

/// Lato: everything else.
TextStyle body(double size, {Color color = C.ink, FontWeight weight = FontWeight.w400, double spacing = 0, double? height}) =>
    GoogleFonts.lato(fontSize: size, color: color, fontWeight: weight, letterSpacing: spacing, height: height);

ThemeData buildTheme() {
  final base = ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(seedColor: C.rose, primary: C.aub, secondary: C.gold2, surface: C.blush),
    scaffoldBackgroundColor: C.blush,
  );
  OutlineInputBorder border(Color c, [double w = 1]) =>
      OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: c, width: w));
  return base.copyWith(
    textTheme: GoogleFonts.latoTextTheme(base.textTheme).apply(bodyColor: C.ink, displayColor: C.ink),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: border(C.line),
      enabledBorder: border(C.line),
      focusedBorder: border(C.gold2, 1.6),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      labelStyle: body(14, color: C.mut, weight: FontWeight.w700),
    ),
    snackBarTheme: SnackBarThemeData(
      backgroundColor: C.aub,
      behavior: SnackBarBehavior.floating,
      contentTextStyle: body(14, color: C.gold, weight: FontWeight.w700),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    ),
    appBarTheme: const AppBarTheme(backgroundColor: C.blush, foregroundColor: C.ink, elevation: 0, scrolledUnderElevation: 0),
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: C.blush,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(30))),
      showDragHandle: true,
    ),
  );
}
