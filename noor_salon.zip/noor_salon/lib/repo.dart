import 'package:cloud_firestore/cloud_firestore.dart';
import 'models.dart';
import 'utils.dart';

class SlotTakenException implements Exception {}

/// All reads and writes to Firestore live here.
///
/// Collections:
///   salon/config   - salon details + ownerUids
///   services, staff, offers
///   users/{uid}    - client name and phone
///   bookings       - appointments
///   locks          - one doc per 30-minute block per artist, so two
///                    people can never book the same chair at the same time
class Repo {
  static FirebaseFirestore get db => FirebaseFirestore.instance;
  static DocumentReference<Map<String, dynamic>> get cfg => db.doc('salon/config');

  // ---------- read ----------
  static Stream<SalonSettings?> settings() =>
      cfg.snapshots().map((d) => d.exists ? SalonSettings.fromMap(d.data()!) : null);

  static Stream<List<Service>> services() =>
      db.collection('services').orderBy('order').snapshots().map((q) => q.docs.map(Service.fromDoc).toList());

  static Stream<List<Staff>> staff() =>
      db.collection('staff').orderBy('order').snapshots().map((q) => q.docs.map(Staff.fromDoc).toList());

  static Stream<List<Offer>> offers() =>
      db.collection('offers').snapshots().map((q) => q.docs.map(Offer.fromDoc).toList());

  static Stream<DocumentSnapshot<Map<String, dynamic>>> user(String uid) => db.doc('users/$uid').snapshots();

  static Stream<List<Booking>> myBookings(String uid) =>
      db.collection('bookings').where('uid', isEqualTo: uid).snapshots().map(_list);

  static Stream<List<Booking>> bookingsFrom(String fromDate) =>
      db.collection('bookings').where('date', isGreaterThanOrEqualTo: fromDate).snapshots().map(_list);

  static Stream<List<Booking>> allBookings() => db.collection('bookings').snapshots().map(_list);

  static List<Booking> _list(QuerySnapshot<Map<String, dynamic>> q) => q.docs.map(Booking.fromDoc).toList();

  // ---------- slot locks ----------
  static String lockId(String date, String staff, int m) => '${date}_${staff}_${pad2(m ~/ 60)}${pad2(m % 60)}';

  static List<String> lockIds(String date, String staff, String time, int dur) {
    final start = toMins(time);
    final n = dur <= 30 ? 1 : (dur / 30).ceil();
    return [for (var i = 0; i < n; i++) lockId(date, staff, start + 30 * i)];
  }

  /// lock id -> booking id, for one day.
  static Stream<Map<String, String>> locksOn(String date) => db
      .collection('locks')
      .where('date', isEqualTo: date)
      .snapshots()
      .map((q) => {for (final d in q.docs) d.id: _s(d.data()['bookingId'])});

  static String _s(dynamic v) => v is String ? v : '';

  // ---------- write ----------
  static Future<void> saveUser(String uid, String name, String phone) => db.doc('users/$uid').set(
      {'name': name, 'phone': phone, 'updatedAt': FieldValue.serverTimestamp()}, SetOptions(merge: true));

  static Future<String> createBooking(Booking b) async {
    final ref = db.collection('bookings').doc();
    final ids = lockIds(b.date, b.staff, b.time, b.dur);
    var taken = false;
    try {
      await db.runTransaction((tx) async {
        for (final id in ids) {
          final s = await tx.get(db.doc('locks/$id'));
          if (s.exists) {
            taken = true;
            throw Exception('slot taken');
          }
        }
        for (final id in ids) {
          tx.set(db.doc('locks/$id'), {'date': b.date, 'staff': b.staff, 'bookingId': ref.id, 'uid': b.uid});
        }
        tx.set(ref, {...b.toMap(), 'createdAt': FieldValue.serverTimestamp()});
      });
    } catch (e) {
      if (taken) throw SlotTakenException();
      rethrow;
    }
    return ref.id;
  }

  static Future<void> reschedule(Booking b, String date, String time, String staff, String staffName) async {
    final oldIds = lockIds(b.date, b.staff, b.time, b.dur).toSet();
    final newIds = lockIds(date, staff, time, b.dur).toSet();
    final toAdd = newIds.difference(oldIds);
    final toRemove = oldIds.difference(newIds);
    var taken = false;
    try {
      await db.runTransaction((tx) async {
        for (final id in toAdd) {
          final s = await tx.get(db.doc('locks/$id'));
          if (s.exists) {
            taken = true;
            throw Exception('slot taken');
          }
        }
        for (final id in toRemove) {
          tx.delete(db.doc('locks/$id'));
        }
        for (final id in toAdd) {
          tx.set(db.doc('locks/$id'), {'date': date, 'staff': staff, 'bookingId': b.id, 'uid': b.uid});
        }
        tx.update(db.doc('bookings/${b.id}'), {'date': date, 'time': time, 'staff': staff, 'staffName': staffName});
      });
    } catch (e) {
      if (taken) throw SlotTakenException();
      rethrow;
    }
  }

  /// Cancelled and no-show bookings free their time slots again.
  static Future<void> setStatus(Booking b, String status, {bool alsoPaid = false}) async {
    final batch = db.batch();
    batch.update(db.doc('bookings/${b.id}'), {'status': status, if (alsoPaid) 'paid': true});
    if (status == 'cancelled' || status == 'noshow') {
      for (final id in lockIds(b.date, b.staff, b.time, b.dur)) {
        batch.delete(db.doc('locks/$id'));
      }
    }
    await batch.commit();
  }

  static Future<void> markPaid(Booking b) => db.doc('bookings/${b.id}').update({'paid': true});

  // ---------- owner ----------
  static Future<void> saveSettings(Map<String, dynamic> data) => cfg.update(data);

  // Admin only (the security rules refuse these for anyone else).
  static Future<void> setOwnerPhones(List<String> phones) => cfg.update({'ownerPhones': phones});
  static Future<void> resetNameChanges() => cfg.update({'nameChanges': 0});

  static Future<void> saveService(Service s) => s.id.isEmpty
      ? db.collection('services').add(s.toMap())
      : db.doc('services/${s.id}').set(s.toMap());

  static Future<void> deleteService(String id) => db.doc('services/$id').delete();

  static Future<void> saveStaff(Staff s) =>
      s.id.isEmpty ? db.collection('staff').add(s.toMap()) : db.doc('staff/${s.id}').set(s.toMap());

  static Future<void> deleteStaff(String id) => db.doc('staff/$id').delete();

  /// The first person to tap "Set up my salon" becomes the owner.
  static Future<void> setupSalon(String uid) async {
    await cfg.set(SalonSettings.sample(uid).toMap());
    final batch = db.batch();
    const services = [
      ['hair', 'Haircut & blow-dry', 45, 2500], ['hair', 'Layer cut', 60, 3500],
      ['hair', 'Global hair colour', 120, 9000], ['hair', 'Highlights / balayage', 150, 14000],
      ['hair', 'Keratin treatment', 180, 18000], ['hair', 'Hair spa', 60, 4000],
      ['skin', 'Hydra facial', 60, 6500], ['skin', 'Whitening facial', 60, 4500], ['skin', 'Deep cleansing', 45, 3000],
      ['nails', 'Manicure', 40, 2000], ['nails', 'Pedicure', 50, 2500], ['nails', 'Gel polish', 45, 3500],
      ['nails', 'Acrylic extensions', 90, 6000],
      ['makeup', 'Party makeup', 60, 8000], ['makeup', 'Nikkah makeup', 120, 25000],
      ['makeup', 'Bridal makeup', 180, 45000], ['makeup', 'Mehndi (both hands)', 60, 3000],
      ['wax', 'Eyebrow threading', 10, 300], ['wax', 'Full face threading', 20, 800],
      ['wax', 'Full arms wax', 30, 1800], ['wax', 'Full legs wax', 40, 2500],
    ];
    for (var i = 0; i < services.length; i++) {
      final s = services[i];
      batch.set(db.collection('services').doc(), {'cat': s[0], 'name': s[1], 'mins': s[2], 'price': s[3], 'order': i});
    }
    const staff = [
      ['Sana Iqbal', 'Senior stylist', 4.9], ['Hira Ahmed', 'Colour expert', 4.8],
      ['Mehwish Raza', 'Bridal artist', 4.9], ['Aqsa Noor', 'Skin & nails', 4.7],
    ];
    for (var i = 0; i < staff.length; i++) {
      batch.set(db.collection('staff').doc(), {'name': staff[i][0], 'role': staff[i][1], 'rate': staff[i][2], 'order': i});
    }
    batch.set(db.doc('offers/MIDWEEK10'), const Offer(
      code: 'MIDWEEK10', desc: 'Tuesday to Thursday, before 3 pm', pct: 10, cap: 1500, days: [2, 3, 4], before: '15:00').toMap());
    batch.set(db.doc('offers/FRIEND500'), const Offer(
      code: 'FRIEND500', desc: 'On bills above 5,000, for you and a friend', flat: 500, min: 5000, cap: 500).toMap());
    await batch.commit();
  }
}
