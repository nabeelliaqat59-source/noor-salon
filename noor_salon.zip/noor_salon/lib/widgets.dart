import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'theme.dart';
import 'utils.dart';

/// Champagne-foil pill button.
class GoldButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final IconData? icon;
  final bool expand;
  const GoldButton(this.label, {super.key, this.onTap, this.icon, this.expand = false});

  @override
  Widget build(BuildContext context) {
    final r = BorderRadius.circular(expand ? 18 : 99);
    return Opacity(
      opacity: onTap == null ? .4 : 1,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: r,
          onTap: onTap,
          child: Ink(
            height: expand ? 56 : 48,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            decoration: BoxDecoration(
              gradient: C.foil,
              borderRadius: r,
              boxShadow: const [BoxShadow(color: Color(0x55C9A15E), blurRadius: 18, offset: Offset(0, 8))],
            ),
            child: Row(
              mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(label, style: body(14.5, color: C.aub, weight: FontWeight.w900)),
                if (icon != null) ...[const SizedBox(width: 6), Icon(icon, size: 18, color: C.aub)],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Aubergine full-width button.
class DarkButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final Color color;
  final Color textColor;
  const DarkButton(this.label, {super.key, this.onTap, this.color = C.aub, this.textColor = C.onDark});

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: onTap == null ? .4 : 1,
      child: Material(
        color: color,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: SizedBox(
            height: 56,
            width: double.infinity,
            child: Center(child: Text(label, style: body(15, color: textColor, weight: FontWeight.w900))),
          ),
        ),
      ),
    );
  }
}

/// Small rounded action button.
class MiniButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final bool primary;
  final Color? textColor;
  final IconData? icon;
  const MiniButton(this.label, {super.key, required this.onTap, this.primary = false, this.textColor, this.icon});

  @override
  Widget build(BuildContext context) {
    final fg = textColor ?? (primary ? C.gold : C.ink);
    return Material(
      color: primary ? C.aub : C.soft,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Container(
          height: 38,
          padding: const EdgeInsets.symmetric(horizontal: 13),
          alignment: Alignment.center,
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            if (icon != null) Icon(icon, size: 16, color: fg),
            if (icon != null && label.isNotEmpty) const SizedBox(width: 5),
            if (label.isNotEmpty) Text(label, style: body(13, color: fg, weight: FontWeight.w700)),
          ]),
        ),
      ),
    );
  }
}

/// Soft white card.
class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  const AppCard({super.key, required this.child, this.padding = const EdgeInsets.all(14), this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: const [
          BoxShadow(color: C.line, offset: Offset(0, 1)),
          BoxShadow(color: Color(0x142B1520), blurRadius: 24, offset: Offset(0, 8), spreadRadius: -12),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: onTap,
          child: Padding(padding: padding, child: child),
        ),
      ),
    );
  }
}

class CircleIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final Color color;
  final bool dot;
  const CircleIconButton(this.icon, {super.key, required this.onTap, this.color = C.ink, this.dot = false});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      shape: const CircleBorder(),
      elevation: 0,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 46,
          height: 46,
          child: Stack(alignment: Alignment.center, children: [
            Icon(icon, size: 21, color: color),
            if (dot)
              Positioned(
                top: 11,
                right: 12,
                child: Container(
                  width: 9,
                  height: 9,
                  decoration: BoxDecoration(color: C.rose, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)),
                ),
              ),
          ]),
        ),
      ),
    );
  }
}

class StatusChip extends StatelessWidget {
  final String status;
  const StatusChip(this.status, {super.key});

  @override
  Widget build(BuildContext context) {
    final s = statusOf(status);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: s.color.withValues(alpha: .13), borderRadius: BorderRadius.circular(99)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 6, height: 6, decoration: BoxDecoration(color: s.color, shape: BoxShape.circle)),
        const SizedBox(width: 6),
        Text(s.label, style: body(11.5, color: s.color, weight: FontWeight.w700)),
      ]),
    );
  }
}

class Avatar extends StatelessWidget {
  final String name;
  final double size;
  final bool ring;
  const Avatar(this.name, {super.key, this.size = 44, this.ring = false});

  @override
  Widget build(BuildContext context) {
    final a = Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: avc(name),
        shape: BoxShape.circle,
        border: ring ? Border.all(color: C.blush, width: 2) : null,
      ),
      child: Text(initials(name), style: display(size * .34, color: Colors.white)),
    );
    if (!ring) return a;
    return Container(padding: const EdgeInsets.all(2), decoration: const BoxDecoration(gradient: C.foil, shape: BoxShape.circle), child: a);
  }
}

/// Aubergine month/day badge.
class DateBox extends StatelessWidget {
  final String date;
  final double width;
  const DateBox(this.date, {super.key, this.width = 62});

  @override
  Widget build(BuildContext context) {
    final d = pdate(date);
    return Container(
      width: width,
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(color: C.aub, borderRadius: BorderRadius.circular(16)),
      child: Column(children: [
        Text(monName(d).toUpperCase(), style: body(11, color: C.gold, weight: FontWeight.w700, spacing: .6)),
        Text('${d.day}', style: display(22, color: C.onDark)),
        Text(dayName(d).toUpperCase(), style: body(10.5, color: C.gold, weight: FontWeight.w700, spacing: .6)),
      ]),
    );
  }
}

/// A card shaped like a ticket with a perforated divider.
class Ticket extends StatelessWidget {
  final Widget top;
  final Widget bottom;
  final Color notch;
  const Ticket({super.key, required this.top, required this.bottom, this.notch = C.blush});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: const [
          BoxShadow(color: C.line, offset: Offset(0, 1)),
          BoxShadow(color: Color(0x1A2B1520), blurRadius: 28, offset: Offset(0, 12), spreadRadius: -18),
        ],
      ),
      child: Column(children: [
        Padding(padding: const EdgeInsets.all(16), child: top),
        SizedBox(
          height: 20,
          child: Stack(clipBehavior: Clip.none, children: [
            Positioned.fill(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: CustomPaint(painter: _DashPainter()),
              ),
            ),
            Positioned(left: -10, top: 0, child: _hole()),
            Positioned(right: -10, top: 0, child: _hole()),
          ]),
        ),
        Padding(padding: const EdgeInsets.fromLTRB(16, 4, 16, 16), child: bottom),
      ]),
    );
  }

  Widget _hole() => Container(width: 20, height: 20, decoration: BoxDecoration(color: notch, shape: BoxShape.circle));
}

class _DashPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = C.line
      ..strokeWidth = 2;
    final y = size.height / 2;
    for (double x = 0; x < size.width; x += 9) {
      canvas.drawLine(Offset(x, y), Offset(math.min(x + 5, size.width), y), p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class SectionTitle extends StatelessWidget {
  final String title;
  final Widget? trailing;
  const SectionTitle(this.title, {super.key, this.trailing});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 26, 0, 12),
      child: Row(children: [
        Expanded(child: Text(title, style: display(19))),
        if (trailing != null) trailing!,
      ]),
    );
  }
}

class Eyebrow extends StatelessWidget {
  final String text;
  final Color color;
  const Eyebrow(this.text, {super.key, this.color = C.mut});

  @override
  Widget build(BuildContext context) =>
      Text(text.toUpperCase(), style: body(11.5, color: color, weight: FontWeight.w700, spacing: 1.6));
}

class PayBadge extends StatelessWidget {
  final String method;
  final double w, h;
  const PayBadge(this.method, {super.key, this.w = 40, this.h = 28});

  @override
  Widget build(BuildContext context) {
    final p = payOf(method);
    return Container(
      width: w,
      height: h,
      alignment: Alignment.center,
      decoration: BoxDecoration(color: p.color, borderRadius: BorderRadius.circular(8)),
      child: Text(p.short, style: body(h * .34, color: Colors.white, weight: FontWeight.w900)),
    );
  }
}

/// Gold progress bar.
class GoldBar extends StatelessWidget {
  final double value;
  final Color track;
  const GoldBar(this.value, {super.key, this.track = C.soft});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: SizedBox(
        height: 7,
        child: Stack(children: [
          Container(color: track),
          FractionallySizedBox(
            widthFactor: value.clamp(0, 1).toDouble(),
            child: Container(decoration: const BoxDecoration(gradient: C.foil)),
          ),
        ]),
      ),
    );
  }
}

class EmptyNote extends StatelessWidget {
  final String text;
  final IconData icon;
  final Widget? action;
  const EmptyNote(this.text, {super.key, this.icon = Icons.event_available_outlined, this.action});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 36, horizontal: 10),
      child: Column(children: [
        Icon(icon, size: 36, color: C.mut),
        const SizedBox(height: 10),
        Text(text, textAlign: TextAlign.center, style: body(14, color: C.mut)),
        if (action != null) ...[const SizedBox(height: 16), action!],
      ]),
    );
  }
}

/// Floating aubergine tab bar with a foil pill on the active tab.
class FloatNav extends StatelessWidget {
  final List<(IconData, String)> items;
  final int index;
  final ValueChanged<int> onTap;
  const FloatNav({super.key, required this.items, required this.index, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        margin: const EdgeInsets.fromLTRB(14, 0, 14, 12),
        height: 66,
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: C.aub,
          borderRadius: BorderRadius.circular(24),
          boxShadow: const [BoxShadow(color: Color(0x882B1520), blurRadius: 30, offset: Offset(0, 14), spreadRadius: -10)],
        ),
        child: Row(children: [
          for (var i = 0; i < items.length; i++)
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => onTap(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 260),
                  curve: Curves.easeOut,
                  decoration: BoxDecoration(
                    gradient: i == index ? C.foil : null,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(items[i].$1, size: 21, color: i == index ? C.aub : C.navText),
                    const SizedBox(height: 3),
                    Text(items[i].$2, style: body(11, color: i == index ? C.aub : C.navText, weight: FontWeight.w700)),
                  ]),
                ),
              ),
            ),
        ]),
      ),
    );
  }
}

/// Gold line-art portrait that draws itself.
class Portrait extends StatefulWidget {
  final double width, height;
  const Portrait({super.key, this.width = 220, this.height = 264});

  @override
  State<Portrait> createState() => _PortraitState();
}

class _PortraitState extends State<Portrait> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 2600))..forward();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) => CustomPaint(
        size: Size(widget.width, widget.height),
        painter: _PortraitPainter(Curves.easeInOut.transform(_c.value)),
      ),
    );
  }
}

class _PortraitPainter extends CustomPainter {
  final double t;
  _PortraitPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 200, size.height / 240);
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..strokeCap = StrokeCap.round
      ..shader = C.foil.createShader(const Rect.fromLTWH(0, 0, 200, 240));
    final p = Path()
      // face profile
      ..moveTo(118, 62)
      ..cubicTo(124, 74, 127, 88, 128, 100)
      ..cubicTo(132, 107, 137, 112, 139, 117)
      ..cubicTo(136, 120, 132, 121, 130, 122)
      ..cubicTo(132, 125, 134, 127, 133, 129)
      ..cubicTo(131, 131, 129, 132, 130, 134)
      ..cubicTo(132, 136, 132, 139, 129, 142)
      ..cubicTo(127, 147, 124, 151, 118, 153)
      ..cubicTo(112, 154, 107, 153, 104, 156)
      ..lineTo(103, 200)
      // back of head and neck
      ..moveTo(118, 62)
      ..cubicTo(106, 46, 82, 44, 69, 57)
      ..cubicTo(56, 70, 58, 92, 64, 108)
      ..cubicTo(69, 122, 78, 134, 82, 144)
      ..cubicTo(84, 164, 82, 182, 80, 200)
      // bun
      ..addOval(Rect.fromCircle(center: const Offset(64, 48), radius: 17))
      ..moveTo(52, 40)
      ..cubicTo(60, 34, 70, 34, 77, 42)
      ..moveTo(50, 52)
      ..cubicTo(60, 56, 70, 54, 77, 46)
      // hair strands
      ..moveTo(76, 70)
      ..cubicTo(70, 84, 70, 100, 76, 114)
      ..moveTo(86, 62)
      ..cubicTo(76, 80, 76, 102, 84, 120)
      // closed eye and brow
      ..moveTo(114, 102)
      ..quadraticBezierTo(120, 106, 125, 103)
      ..moveTo(113, 95)
      ..quadraticBezierTo(120, 92, 126, 95)
      // earring
      ..addOval(Rect.fromCircle(center: const Offset(88, 124), radius: 2.5))
      ..moveTo(88, 127)
      ..lineTo(88, 135)
      ..addOval(Rect.fromCircle(center: const Offset(88, 138), radius: 3))
      // shoulders
      ..moveTo(30, 240)
      ..cubicTo(40, 214, 62, 202, 80, 200)
      ..moveTo(103, 200)
      ..cubicTo(122, 204, 150, 214, 172, 240)
      // sparkles
      ..moveTo(150, 40)
      ..lineTo(150, 64)
      ..moveTo(138, 52)
      ..lineTo(162, 52)
      ..moveTo(168, 92)
      ..lineTo(168, 104)
      ..moveTo(162, 98)
      ..lineTo(174, 98);
    for (final m in p.computeMetrics()) {
      canvas.drawPath(m.extractPath(0, m.length * t), paint);
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _PortraitPainter old) => old.t != t;
}

/// Falling gold and rose confetti, plays once.
class Confetti extends StatefulWidget {
  const Confetti({super.key});

  @override
  State<Confetti> createState() => _ConfettiState();
}

class _ConfettiState extends State<Confetti> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 3000))..forward();
  final _rnd = math.Random();
  late final List<List<double>> _bits =
      List.generate(48, (i) => [_rnd.nextDouble(), _rnd.nextDouble() * .35, .7 + _rnd.nextDouble() * .6, _rnd.nextDouble() * 6, i % 5 + 0.0]);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: _c,
        builder: (_, __) => CustomPaint(size: Size.infinite, painter: _ConfettiPainter(_c.value, _bits)),
      ),
    );
  }
}

class _ConfettiPainter extends CustomPainter {
  final double t;
  final List<List<double>> bits;
  _ConfettiPainter(this.t, this.bits);
  static const colors = [Color(0xFFF3DFB2), Color(0xFFC9A15E), Color(0xFFE597A2), C.rose, Colors.white];

  @override
  void paint(Canvas canvas, Size size) {
    for (final b in bits) {
      final p = ((t - b[1]) / (1 - b[1])).clamp(0.0, 1.0);
      if (p <= 0) continue;
      final y = -20 + p * b[2] * (size.height + 40);
      final x = b[0] * size.width + math.sin(p * 8 + b[3]) * 14;
      canvas.save();
      canvas.translate(x, y);
      canvas.rotate(p * 9 + b[3]);
      canvas.drawRRect(
        RRect.fromRectAndRadius(const Rect.fromLTWH(-3.5, -6, 7, 12), const Radius.circular(2)),
        Paint()..color = colors[b[4].toInt()].withValues(alpha: 1 - p * .7),
      );
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant _ConfettiPainter old) => old.t != t;
}

/// Splash: gold arch monogram and wordmark.
class SplashView extends StatelessWidget {
  final String word;
  const SplashView({super.key, required this.word});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: RadialGradient(center: Alignment(0, -.2), radius: 1.0, colors: [Color(0xFF5A2A3E), C.aub], stops: [0, .75]),
      ),
      child: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const SizedBox(width: 110, height: 140, child: CustomPaint(painter: _MonogramPainter())),
          const SizedBox(height: 18),
          Text(word.toUpperCase(), style: display(34, color: C.onDark, spacing: 10)),
          const SizedBox(height: 6),
          Text('BEAUTY LOUNGE', style: body(11, color: C.gold, weight: FontWeight.w700, spacing: 5)),
        ]),
      ),
    );
  }
}

class _MonogramPainter extends CustomPainter {
  const _MonogramPainter();

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 120, size.height / 150);
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4
      ..shader = C.foil.createShader(const Rect.fromLTWH(0, 0, 120, 150));
    final p = Path()
      ..moveTo(10, 148)
      ..lineTo(10, 60)
      ..arcToPoint(const Offset(110, 60), radius: const Radius.circular(50))
      ..lineTo(110, 148)
      ..moveTo(20, 148)
      ..lineTo(20, 62)
      ..arcToPoint(const Offset(100, 62), radius: const Radius.circular(40))
      ..lineTo(100, 148)
      ..moveTo(42, 118)
      ..lineTo(42, 58)
      ..lineTo(78, 118)
      ..lineTo(78, 58)
      ..addOval(Rect.fromCircle(center: const Offset(60, 28), radius: 3));
    canvas.drawPath(p, paint);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Text painted with the champagne foil gradient.
class FoilText extends StatelessWidget {
  final String text;
  final TextStyle style;
  const FoilText(this.text, {super.key, required this.style});

  @override
  Widget build(BuildContext context) {
    return ShaderMask(
      blendMode: BlendMode.srcIn,
      shaderCallback: (r) => C.foil.createShader(r),
      child: Text(text, style: style.copyWith(color: Colors.white)),
    );
  }
}

/// Selectable row used for artists and payment methods.
class RadioTile extends StatelessWidget {
  final bool selected;
  final Widget leading;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const RadioTile({super.key, required this.selected, required this.leading, required this.title, this.subtitle = '', required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: selected ? C.gold2 : C.line, width: selected ? 2 : 1),
            ),
            child: Row(children: [
              leading,
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(title, style: body(15, weight: FontWeight.w700)),
                  if (subtitle.isNotEmpty) Text(subtitle, style: body(13, color: C.mut)),
                ]),
              ),
              AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: 22,
                height: 22,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: selected ? C.gold2 : C.line, width: selected ? 7 : 2),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
