import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'screens/auth.dart';
import 'screens/customer.dart';
import 'screens/owner.dart';
import 'state.dart';
import 'theme.dart';
import 'widgets.dart';

/// Decides which screen to show: login, name, salon setup, owner or client.
class AppRoot extends StatefulWidget {
  const AppRoot({super.key});

  @override
  State<AppRoot> createState() => _AppRootState();
}

class _AppRootState extends State<AppRoot> {
  bool _authKnown = false;
  User? _user;
  bool _splash = true;
  StreamSubscription<User?>? _sub;

  @override
  void initState() {
    super.initState();
    _sub = FirebaseAuth.instance.authStateChanges().listen((u) {
      if (u != null) {
        app.start(u.uid, u.phoneNumber ?? '');
      } else {
        app.stop();
      }
      setState(() {
        _user = u;
        _authKnown = true;
      });
    });
    Future.delayed(const Duration(milliseconds: 2400), () {
      if (mounted) setState(() => _splash = false);
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Widget _content() {
    if (!_authKnown) return const SizedBox.shrink();
    if (_user == null) return const LoginScreen();
    if (!app.userLoaded || !app.settingsLoaded) {
      return const Scaffold(body: Center(child: CircularProgressIndicator(color: C.gold2)));
    }
    if (!app.userExists) return const ProfileSetupScreen();
    if (app.settings == null) return const SetupSalonScreen();
    return app.isOwner ? const OwnerShell() : const CustomerShell();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Positioned.fill(child: ListenableBuilder(listenable: app, builder: (_, __) => _content())),
      Positioned.fill(
        child: IgnorePointer(
          ignoring: !_splash,
          child: AnimatedOpacity(
            opacity: _splash ? 1 : 0,
            duration: const Duration(milliseconds: 600),
            child: const SplashView(word: 'Noor'),
          ),
        ),
      ),
    ]);
  }
}
