import 'package:cloud_firestore/cloud_firestore.dart';

int _int(dynamic v, [int d = 0]) => v is num ? v.toInt() : d;
double _dbl(dynamic v, [double d = 0]) => v is num ? v.toDouble() : d;
String _str(dynamic v, [String d = '']) => v is String ? v : d;
List<String> _strs(dynamic v) => v is List ? v.map((e) => e.toString()).toList() : <String>[];

class SalonSettings {
  final String name, tag, city, area, cur, open, close, phone;
  final List<String> ownerUids;

  /// Admins (the person who first set up the app) can change everything, any number of times.
  final List<String> superAdminUids;

  /// Mobile numbers (+92...) the admin has made salon owners.
  final List<String> ownerPhones;

  /// How many times a non-admin owner has changed the salon name. Limit: [maxNameChanges].
  final int nameChanges;
  static const maxNameChanges = 2;

  const SalonSettings({
    required this.name,
    required this.tag,
    required this.city,
    required this.area,
    required this.cur,
    required this.open,
    required this.close,
    required this.phone,
    required this.ownerUids,
    this.superAdminUids = const [],
    this.ownerPhones = const [],
    this.nameChanges = 0,
  });

  int get nameChangesLeft => (maxNameChanges - nameChanges).clamp(0, maxNameChanges);

  factory SalonSettings.fromMap(Map<String, dynamic> m) => SalonSettings(
        name: _str(m['name'], 'My Salon'),
        tag: _str(m['tag']),
        city: _str(m['city']),
        area: _str(m['area']),
        cur: _str(m['cur'], 'Rs'),
        open: _str(m['open'], '11:00'),
        close: _str(m['close'], '20:00'),
        phone: _str(m['phone']),
        ownerUids: _strs(m['ownerUids']),
        superAdminUids: _strs(m['superAdminUids']),
        ownerPhones: _strs(m['ownerPhones']),
        nameChanges: _int(m['nameChanges']),
      );

  Map<String, dynamic> toMap() => {
        'name': name, 'tag': tag, 'city': city, 'area': area, 'cur': cur,
        'open': open, 'close': close, 'phone': phone, 'ownerUids': ownerUids,
        'superAdminUids': superAdminUids, 'ownerPhones': ownerPhones, 'nameChanges': nameChanges,
      };

  static SalonSettings sample(String ownerUid) => SalonSettings(
        name: 'Noor Beauty Lounge',
        tag: 'Hair · Skin · Bridal',
        city: 'Lahore',
        area: 'MM Alam Road, Gulberg III',
        cur: 'Rs',
        open: '11:00',
        close: '20:00',
        phone: '042-35761190',
        ownerUids: [ownerUid],
        superAdminUids: [ownerUid],
      );
}

class Service {
  final String id, cat, name;
  final int mins, price, order;
  const Service({required this.id, required this.cat, required this.name, required this.mins, required this.price, this.order = 0});

  factory Service.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return Service(id: d.id, cat: _str(m['cat'], 'hair'), name: _str(m['name']), mins: _int(m['mins'], 30), price: _int(m['price']), order: _int(m['order']));
  }

  Map<String, dynamic> toMap() => {'cat': cat, 'name': name, 'mins': mins, 'price': price, 'order': order};
}

class Staff {
  final String id, name, role;
  final double rate;
  final int order;
  const Staff({required this.id, required this.name, required this.role, this.rate = 0, this.order = 0});

  factory Staff.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return Staff(id: d.id, name: _str(m['name']), role: _str(m['role']), rate: _dbl(m['rate']), order: _int(m['order']));
  }

  Map<String, dynamic> toMap() => {'name': name, 'role': role, 'rate': rate, 'order': order};
}

class Offer {
  final String code, desc;
  final int pct, flat, min, cap;
  final List<int> days; // DateTime.weekday values (1 = Monday). Empty = every day.
  final String before; // 'HH:mm' or '' for any time.

  const Offer({required this.code, required this.desc, this.pct = 0, this.flat = 0, this.min = 0, this.cap = 0, this.days = const [], this.before = ''});

  factory Offer.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return Offer(
      code: d.id,
      desc: _str(m['desc']),
      pct: _int(m['pct']),
      flat: _int(m['flat']),
      min: _int(m['min']),
      cap: _int(m['cap']),
      days: m['days'] is List ? (m['days'] as List).map((e) => _int(e)).toList() : <int>[],
      before: _str(m['before']),
    );
  }

  Map<String, dynamic> toMap() => {'desc': desc, 'pct': pct, 'flat': flat, 'min': min, 'cap': cap, 'days': days, 'before': before};
}

class Booking {
  final String id, uid, cust, phone, staff, staffName, date, time, status, pay;
  final List<String> svc, svcNames;
  final int dur, gross, disc;
  final bool paid;

  const Booking({
    this.id = '',
    required this.uid,
    required this.cust,
    required this.phone,
    required this.svc,
    required this.svcNames,
    required this.staff,
    required this.staffName,
    required this.date,
    required this.time,
    required this.dur,
    required this.gross,
    this.disc = 0,
    this.status = 'confirmed',
    this.pay = 'cash',
    this.paid = false,
  });

  int get total => (gross - disc) < 0 ? 0 : gross - disc;
  String get title => svcNames.join(' + ');
  String get ref => '#NB-${(id.length >= 5 ? id.substring(0, 5) : id).toUpperCase()}';
  String get sortKey => '$date $time';

  Booking copyWith({String? id, String? date, String? time, String? staff, String? staffName, String? status, bool? paid}) => Booking(
        id: id ?? this.id,
        uid: uid,
        cust: cust,
        phone: phone,
        svc: svc,
        svcNames: svcNames,
        staff: staff ?? this.staff,
        staffName: staffName ?? this.staffName,
        date: date ?? this.date,
        time: time ?? this.time,
        dur: dur,
        gross: gross,
        disc: disc,
        status: status ?? this.status,
        pay: pay,
        paid: paid ?? this.paid,
      );

  factory Booking.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return Booking(
      id: d.id,
      uid: _str(m['uid']),
      cust: _str(m['cust']),
      phone: _str(m['phone']),
      svc: _strs(m['svc']),
      svcNames: _strs(m['svcNames']),
      staff: _str(m['staff']),
      staffName: _str(m['staffName']),
      date: _str(m['date']),
      time: _str(m['time'], '11:00'),
      dur: _int(m['dur'], 30),
      gross: _int(m['gross']),
      disc: _int(m['disc']),
      status: _str(m['status'], 'confirmed'),
      pay: _str(m['pay'], 'cash'),
      paid: m['paid'] == true,
    );
  }

  Map<String, dynamic> toMap() => {
        'uid': uid, 'cust': cust, 'phone': phone, 'svc': svc, 'svcNames': svcNames,
        'staff': staff, 'staffName': staffName, 'date': date, 'time': time, 'dur': dur,
        'gross': gross, 'disc': disc, 'status': status, 'pay': pay, 'paid': paid,
      };
}
