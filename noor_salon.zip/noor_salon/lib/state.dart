import 'dart:async';
import 'package:flutter/foundation.dart';
import 'models.dart';
import 'repo.dart';
import 'utils.dart';

/// Live app data shared by every screen. Screens rebuild with
/// `ListenableBuilder(listenable: app, ...)`.
class AppState extends ChangeNotifier {
  String uid = '';
  String authPhone = '';
  SalonSettings? settings;
  bool settingsLoaded = false;
  bool userLoaded = false;
  bool userExists = false;
  String userName = '';
  String userPhone = '';
  List<Service> services = [];
  List<Staff> staff = [];
  List<Offer> offers = [];
  List<Booking> mine = [];

  final List<StreamSubscription> _subs = [];

  /// The person who set up the app. Unlimited edits.
  bool get isSuper => settings != null && settings!.superAdminUids.contains(uid);

  bool get isOwner =>
      settings != null &&
      (isSuper || settings!.ownerUids.contains(uid) || (authPhone.isNotEmpty && settings!.ownerPhones.contains(authPhone)));
  String get cur => settings?.cur ?? 'Rs';
  String money(num n) => fmtMoney(cur, n);

  Service? svc(String id) {
    for (final s in services) {
      if (s.id == id) return s;
    }
    return null;
  }

  Staff? stf(String id) {
    for (final s in staff) {
      if (s.id == id) return s;
    }
    return null;
  }

  int get points => mine.where((b) => b.status == 'done').fold<int>(0, (a, b) => a + b.total) ~/ 100;

  void start(String newUid, String phone) {
    if (uid == newUid && _subs.isNotEmpty) return;
    stop(notify: false);
    uid = newUid;
    authPhone = phone;
    void done() => notifyListeners();
    _subs.add(Repo.settings().listen((s) {
      settings = s;
      settingsLoaded = true;
      done();
    }, onError: (_) {
      settingsLoaded = true;
      done();
    }));
    _subs.add(Repo.user(newUid).listen((d) {
      userLoaded = true;
      userExists = d.exists;
      final m = d.data() ?? {};
      userName = (m['name'] ?? '') as String;
      userPhone = (m['phone'] ?? phone) as String;
      done();
    }, onError: (_) {
      userLoaded = true;
      done();
    }));
    _subs.add(Repo.services().listen((v) {
      services = v;
      done();
    }, onError: (_) {}));
    _subs.add(Repo.staff().listen((v) {
      staff = v;
      done();
    }, onError: (_) {}));
    _subs.add(Repo.offers().listen((v) {
      offers = v;
      done();
    }, onError: (_) {}));
    _subs.add(Repo.myBookings(newUid).listen((v) {
      mine = v;
      done();
    }, onError: (_) {}));
  }

  void stop({bool notify = true}) {
    for (final s in _subs) {
      s.cancel();
    }
    _subs.clear();
    uid = '';
    settings = null;
    settingsLoaded = false;
    userLoaded = false;
    userExists = false;
    userName = '';
    userPhone = '';
    services = [];
    staff = [];
    offers = [];
    mine = [];
    if (notify) notifyListeners();
  }
}

final app = AppState();
