import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'theme.dart';

String pad2(int n) => n.toString().padLeft(2, '0');
String ymd(DateTime d) => '${d.year}-${pad2(d.month)}-${pad2(d.day)}';

DateTime pdate(String s) {
  final p = s.split('-').map(int.parse).toList();
  return DateTime(p[0], p[1], p[2], 12);
}

DateTime dayFromToday(int n) {
  final now = DateTime.now();
  return DateTime(now.year, now.month, now.day + n, 12);
}

String todayStr() => ymd(DateTime.now());

const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
String dayName(DateTime d) => weekDays[d.weekday - 1];
String monName(DateTime d) => months[d.month - 1];

String fdate(String s) {
  if (s == todayStr()) return 'Today';
  if (s == ymd(dayFromToday(1))) return 'Tomorrow';
  final d = pdate(s);
  return '${dayName(d)}, ${d.day} ${monName(d)}';
}

int toMins(String t) {
  final p = t.split(':');
  return int.parse(p[0]) * 60 + int.parse(p[1]);
}

String fromMins(int m) => '${pad2(m ~/ 60)}:${pad2(m % 60)}';

String t12(String t) {
  final m = toMins(t);
  var h = m ~/ 60;
  final ap = h >= 12 ? 'PM' : 'AM';
  h = h % 12;
  if (h == 0) h = 12;
  return '$h:${pad2(m % 60)} $ap';
}

int nowMins() {
  final n = DateTime.now();
  return n.hour * 60 + n.minute;
}

final _nf = NumberFormat('#,##0', 'en_US');
String fmtMoney(String cur, num n) => '$cur ${_nf.format(n.round())}';

String initials(String s) {
  final w = s.trim().split(RegExp(r'\s+')).where((x) => x.isNotEmpty).take(2).toList();
  if (w.isEmpty) return '?';
  return w.map((x) => x[0].toUpperCase()).join();
}

const _avatarColors = <Color>[
  Color(0xFFB85F6C), Color(0xFF7D4F86), Color(0xFF4F7F78), Color(0xFFB0814A),
  Color(0xFF5D6FA3), Color(0xFF9C4F78), Color(0xFF6F7B4B),
];
Color avc(String s) => _avatarColors[s.codeUnits.fold<int>(0, (a, c) => a + c) % _avatarColors.length];

class Cat {
  final String id, label;
  final IconData icon;
  const Cat(this.id, this.label, this.icon);
}

const cats = <Cat>[
  Cat('hair', 'Hair', Icons.content_cut),
  Cat('skin', 'Skin', Icons.face_retouching_natural),
  Cat('nails', 'Nails', Icons.back_hand_outlined),
  Cat('makeup', 'Bridal', Icons.brush_outlined),
  Cat('wax', 'Wax', Icons.spa_outlined),
];

Cat catOf(String id) => cats.firstWhere((c) => c.id == id, orElse: () => cats.first);

class StatusInfo {
  final String label;
  final Color color;
  const StatusInfo(this.label, this.color);
}

const statuses = <String, StatusInfo>{
  'confirmed': StatusInfo('Confirmed', C.ok),
  'in': StatusInfo('In chair', C.warn),
  'done': StatusInfo('Completed', Color(0xFF6B7FB0)),
  'cancelled': StatusInfo('Cancelled', C.bad),
  'noshow': StatusInfo('No-show', C.bad),
};
StatusInfo statusOf(String s) => statuses[s] ?? const StatusInfo('Unknown', C.mut);

class PayInfo {
  final String label, short;
  final Color color;
  const PayInfo(this.label, this.short, this.color);
}

const payMethods = <String, PayInfo>{
  'cash': PayInfo('Cash at salon', 'CASH', Color(0xFF6F7B4B)),
  'jazzcash': PayInfo('JazzCash', 'Jazz', Color(0xFFC1272D)),
  'easypaisa': PayInfo('EasyPaisa', 'ep', Color(0xFF1FA463)),
  'card': PayInfo('Debit / credit card', 'CARD', Color(0xFF2E3B6E)),
};
PayInfo payOf(String k) => payMethods[k] ?? payMethods['cash']!;

void toast(BuildContext context, String msg) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg)));
}

/// Close any open screens, then sign out. AppRoot shows the login screen.
Future<void> signOut(BuildContext context) async {
  Navigator.of(context).popUntil((r) => r.isFirst);
  await FirebaseAuth.instance.signOut();
}
