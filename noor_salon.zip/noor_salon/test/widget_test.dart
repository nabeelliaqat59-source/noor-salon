import 'package:flutter_test/flutter_test.dart';
import 'package:noor_salon/utils.dart';

void main() {
  test('time helpers', () {
    expect(t12('13:30'), '1:30 PM');
    expect(toMins('11:00'), 660);
    expect(fromMins(690), '11:30');
  });
}
